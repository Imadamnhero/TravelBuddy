package com.nikmesoft.nmsharekit.objects;

public class NMShareMessage {
	public enum NMShareType {
		NMShareTypeStatus, NMShareTypeStory;
	}

	private String message;
	private String name;
	private String caption;
	private String description;
	private String link;
	private String picture;
	private NMShareType type;

	public NMShareMessage() {

	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public NMShareType getType() {
		return type;
	}

	public void setType(NMShareType type) {
		this.type = type;
	}

}
