package com.nikmesoft.nmsharekit.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Utils {
	public static Bitmap decodeSampledBitmapFromFile(
			String file, int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(file, options);
		int fileWidth = options.outWidth;
		int fileHeight = options.outHeight;
		if (fileWidth == -1 || fileHeight == -1) {
			return null;
		}

		// Calculate inSampleSize
		float widthRatio = (float) reqWidth / (float) fileWidth;
		float heightRatio = (float) reqHeight / (float) fileHeight;
		int realPreviewWidth, realPreviewHeight;
		int sample;
		if (widthRatio < heightRatio) {
			realPreviewWidth = (int) (fileWidth * widthRatio);
			realPreviewHeight = (int) (fileHeight * widthRatio);
			sample = (int) ((1 / widthRatio) + 1.0f);
		} else {
			realPreviewWidth = (int) (fileWidth * heightRatio);
			realPreviewHeight = (int) (fileHeight * heightRatio);
			sample = (int) ((1 / heightRatio) + 1.0f);
		}

		options = new BitmapFactory.Options();

		options.inJustDecodeBounds = false;
		options.inPurgeable = true;
		options.inInputShareable = true;
		options.outHeight = realPreviewHeight;
		options.outWidth = realPreviewWidth;
		options.inSampleSize = sample;

		return BitmapFactory.decodeFile(file, options);
	}
}
