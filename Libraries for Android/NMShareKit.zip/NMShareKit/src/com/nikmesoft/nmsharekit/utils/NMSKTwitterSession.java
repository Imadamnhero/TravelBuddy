package com.nikmesoft.nmsharekit.utils;

import twitter4j.auth.AccessToken;

import com.nikmesoft.nmsharekit.configers.NMSKDevDefine;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class NMSKTwitterSession {

	private SharedPreferences sharedPref;
	private Editor editor;
	private static NMSKTwitterSession instance = null;

	private NMSKTwitterSession(Context context) {
		sharedPref = context.getSharedPreferences(
				NMSKDevDefine.PREFERENCE_NAME, Context.MODE_PRIVATE);

	}

	public static NMSKTwitterSession getInstance(Context context) {
		if (instance == null) {
			instance = new NMSKTwitterSession(context);
		}
		return instance;
	}

	public void storeAccessToken(AccessToken accessToken, String username) {
		editor = sharedPref.edit();
		editor.putString(NMSKDevDefine.PREF_TW_KEY_TOKEN,
				accessToken.getToken());
		editor.putString(NMSKDevDefine.PREF_TW_KEY_SECRET,
				accessToken.getTokenSecret());
		editor.putString(NMSKDevDefine.PREF_TW_KEY_USERNAME, username);
		editor.commit();
	}

	public void resetAccessToken() {
		editor = sharedPref.edit();
		editor.putString(NMSKDevDefine.PREF_TW_KEY_TOKEN, null);
		editor.putString(NMSKDevDefine.PREF_TW_KEY_SECRET, null);
		editor.putString(NMSKDevDefine.PREF_TW_KEY_USERNAME, null);
		editor.commit();
	}

	public AccessToken getAccessToken() {
		String token = sharedPref.getString(NMSKDevDefine.PREF_TW_KEY_TOKEN,
				null);
		String tokenSecret = sharedPref.getString(
				NMSKDevDefine.PREF_TW_KEY_SECRET, null);

		if (token != null && tokenSecret != null)
			return new AccessToken(token, tokenSecret);
		else
			return null;
	}

	public String getUsername() {
		return sharedPref.getString(NMSKDevDefine.PREF_TW_KEY_USERNAME, null);
	}

}
