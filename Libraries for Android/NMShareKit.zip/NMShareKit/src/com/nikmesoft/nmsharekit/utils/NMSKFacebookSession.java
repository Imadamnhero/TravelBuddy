//
// 	FacebookSession.java
//  NMShareKit
//
// Created by Linh NGUYEN on Jan 1, 2013.
// Copyright (c) 2013 Nikmesoft Co., Ltd. All rights reserved.
// http://www.mobioneer.com
//
package com.nikmesoft.nmsharekit.utils;

import com.facebook.Session;
import com.nikmesoft.nmsharekit.configers.NMSKDevDefine;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;

public class NMSKFacebookSession {
	private SharedPreferences sharedPref;
	private Editor editor;
	private static NMSKFacebookSession instance = null;

	private NMSKFacebookSession(Context context) {
		sharedPref = context.getSharedPreferences(
				NMSKDevDefine.PREFERENCE_NAME, Context.MODE_PRIVATE);

	}

	public static NMSKFacebookSession getInstance(Context context) {
		if (instance == null) {
			instance = new NMSKFacebookSession(context);
		}
		return instance;
	}

	public void storeAccessToken(String accessToken) {
		editor = sharedPref.edit();
		editor.putString(NMSKDevDefine.PREF_FB_KEY_TOKEN, accessToken);
		editor.commit();
	}

	public void resetAccessToken() {
		editor = sharedPref.edit();
		editor.putString(NMSKDevDefine.PREF_FB_KEY_TOKEN, null);
		editor.putString(NMSKDevDefine.PREF_FB_KEY_USERNAME, null);
		editor.commit();
	}

	public void storeUsername(String username) {
		editor = sharedPref.edit();
		editor.putString(NMSKDevDefine.PREF_FB_KEY_USERNAME, username);
		editor.commit();
	}

	public String getAccessToken() {
		return sharedPref.getString(NMSKDevDefine.PREF_FB_KEY_TOKEN, null);
	}

	public String getUsername() {
		return sharedPref.getString(NMSKDevDefine.PREF_FB_KEY_USERNAME, null);
	}

	public void saveSession(Bundle outState) {
		Session session = Session.getActiveSession();
		if (session != null) {
			Session.saveSession(session, outState);
		}
	}

	public void onActivityResult(Activity activity, int requestCode,
			int resultCode, Intent data) {
		Session session = Session.getActiveSession();
		if (session != null) {
			session.onActivityResult(activity, requestCode, resultCode, data);
		}
	}
}