package com.nikmesoft.nmsharekit;

import android.app.Activity;

import com.nikmesoft.nmsharekit.helpers.NMSKFacebookHelper;
import com.nikmesoft.nmsharekit.helpers.NMSKTwitterHelper;
import com.nikmesoft.nmsharekit.objects.NMShareMessage;

public class NMShareKit {
	public static NMShareKit instance;
	private Activity activity;

	private NMShareKit(Activity activity) {
		this.activity = activity;

	}

	// share instance
	public static NMShareKit sharedInstance(Activity activity) {
		NMShareKit instance = new NMShareKit(activity);
		return instance;
	}

	// share to FB with shareMessage
	public void shareFB(NMShareMessage message) {
		NMSKFacebookHelper.sharedInstance(activity).share(message);
	}

	// share to FB with shareMessage
	public void shareTwitter(NMShareMessage message) {
		NMSKTwitterHelper.sharedInstance(activity).share(message);
	}
}
