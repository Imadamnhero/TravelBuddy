package com.nikmesoft.nmsharekit.configers;


public class NMSKDevDefine {

	public static String PREFERENCE_NAME = "NMShareKit";
	public static final String PREF_FB_KEY_TOKEN = "fb_oauth_token";
	public static final String PREF_FB_KEY_USERNAME = "fb_username";
	public static final String PREF_FB_KEY_SECRET = "fb_oauth_token_secret";
	public static final String PREF_TW_KEY_TOKEN = "tw_oauth_token";
	public static final String PREF_TW_KEY_USERNAME = "tw_username";
	public static final String PREF_TW_KEY_SECRET = "tw_oauth_token_secret";
	public static final String PREF_TW_AUTH_URL = "tw_auth_url";
	public static final String PREF_TW_OAUTH_VERIFIER = "tw_oauth_verifier";
	public static final String PREF_TW_OAUTH_TOKEN = "tw_oauth_token";

	public static NMSKDevDefine instance;
	private String twitterConsumerKey;
	private String twitterSecretKey;
	private String twitterCallBack;

	private NMSKDevDefine() {

	}

	// share instance
	public static NMSKDevDefine sharedInstance() {
		if (instance == null) {
			instance = new NMSKDevDefine();
		}
		return instance;
	}

	public String getTwitterConsumerKey() {
		return twitterConsumerKey;
	}

	public void setTwitterConsumerKey(String twitterConsumerKey) {
		this.twitterConsumerKey = twitterConsumerKey;
	}

	public String getTwitterSecretKey() {
		return twitterSecretKey;
	}

	public void setTwitterSecretKey(String twitterSecretKey) {
		this.twitterSecretKey = twitterSecretKey;
	}

	public String getTwitterCallBack() {
		return twitterCallBack;
	}

	public void setTwitterCallBack(String twitterCallBack) {
		this.twitterCallBack = twitterCallBack;
	}

}
