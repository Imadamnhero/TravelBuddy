package com.nikmesoft.nmsharekit.delegates;

import com.nikmesoft.nmsharekit.objects.NMShareMessage;

public interface NMSKTwitterDialogDelegate {

	void cancel();

	void didSharedWithMessage(NMShareMessage message);

}
