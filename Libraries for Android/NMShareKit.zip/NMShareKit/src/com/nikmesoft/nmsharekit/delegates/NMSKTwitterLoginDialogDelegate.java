package com.nikmesoft.nmsharekit.delegates;

public interface NMSKTwitterLoginDialogDelegate {

	void onComplete(String value);

	void onError(String value);
}
