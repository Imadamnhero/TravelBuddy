package com.nikmesoft.nmsharekit.delegates;

import com.nikmesoft.nmsharekit.objects.NMShareMessage;

public interface NMSKFacebookDialogDelegate {

	void cancel();

	void didSharedWithMessage(NMShareMessage message);

}
