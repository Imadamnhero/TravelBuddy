//
// 	MBNRKDialog.java
//  MBNRatingKit
//
// Created by Linh NGUYEN on Dec 28, 2012.
// Copyright (c) 2012 Mobioneer Co., Ltd. All rights reserved.
// http://www.mobioneer.com
//
package com.nikmesoft.nmsharekit.views;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.nikmesoft.nmsharekit.R;

/**
 * @author Linh NGUYEN
 * 
 */
public abstract class NMSKDialog extends Dialog implements OnClickListener {
	private ViewGroup contentView;
	private TextView nav_title;
	protected Button nav_btn_left, nav_btn_right;
	protected Activity activity;

	// contructor
	public NMSKDialog(Activity activity) {
		super(activity, R.style.MBNRT_Dialog);
		this.activity = activity;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		contentView = (ViewGroup) getWindow().getDecorView().findViewById(
				android.R.id.content);
		contentView.setBackgroundResource(R.drawable.bg_general);
	}

	public abstract void initComponents();

	public abstract void addListenner();

	public void setBackgroundResource(int resid) {
		if (resid != 0) {
			contentView.setBackgroundColor(Color.argb(1, 238, 238, 238));
			contentView.invalidate();
		}
	}

	public void setTitle(String title) {
		if (nav_title != null) {
			nav_title.setText(title);
		}
	}

	public void addNavigation(String title, int btnLeftResID, int btnRightResID) {
		View rootView = ((ViewGroup) contentView.getChildAt(0)).getChildAt(0);
		addNavigation(rootView, title, btnLeftResID, btnRightResID);
	}

	public void addNavigation(View rootView, String title, int btnLeftResID,
			int btnRightResID) {

		View nav_layout = rootView.findViewById(R.id.nav_layout);
		nav_title = (TextView) rootView.findViewById(R.id.nav_title);
		nav_btn_left = (Button) rootView.findViewById(R.id.nav_bt_left);
		nav_btn_right = (Button) rootView.findViewById(R.id.nav_bt_right);

		nav_layout.setVisibility(View.VISIBLE);
		nav_title.setText(title);
		if (btnLeftResID != 0) {
			nav_btn_left.setBackgroundResource(btnLeftResID);
		} else {
			nav_btn_left.setVisibility(View.GONE);
		}
		if (btnRightResID != 0) {
			nav_btn_right.setBackgroundResource(btnRightResID);
		} else {
			nav_btn_right.setVisibility(View.GONE);
		}
	}

	public void setBtnLeftOnclickListenner(View.OnClickListener clickListener) {
		nav_btn_left.setOnClickListener(clickListener);
	}

	public void setBtnRightOnclickListenner(View.OnClickListener clickListener) {
		nav_btn_right.setOnClickListener(clickListener);
	}

	public int getBtnLeftId() {
		return nav_btn_left.getId();
	}

	public int getBtnRightId() {
		return nav_btn_right.getId();
	}

	public void disableBtnLeft(boolean disable) {
		nav_btn_left.setEnabled(!disable);
	}

	public void disableBtnright(boolean disable) {
		nav_btn_right.setEnabled(!disable);
	}

	public void changeBtnLeft(int btnLeftResID) {
		if (btnLeftResID != 0) {
			nav_btn_left.setBackgroundResource(btnLeftResID);
		} else {
			nav_btn_left.setVisibility(View.GONE);
		}
	}

	public void changeBtnRight(int btnRightResID) {
		if (btnRightResID != 0) {
			nav_btn_right.setBackgroundResource(btnRightResID);
		} else {
			nav_btn_right.setVisibility(View.GONE);
		}
	}
}
