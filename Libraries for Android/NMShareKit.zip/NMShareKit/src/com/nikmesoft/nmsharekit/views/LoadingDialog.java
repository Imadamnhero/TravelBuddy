package com.nikmesoft.nmsharekit.views;

import android.app.Dialog;
import android.content.Context;

import com.nikmesoft.nmsharekit.R;

public class LoadingDialog extends Dialog{

	public LoadingDialog(Context context) {
		super(context, R.style.DialogTheme);
		setContentView(R.layout.layout_progressbar);
	}
	
}
