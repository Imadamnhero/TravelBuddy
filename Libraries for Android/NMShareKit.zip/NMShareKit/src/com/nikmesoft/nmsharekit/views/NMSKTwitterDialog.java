package com.nikmesoft.nmsharekit.views;

import java.io.File;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.nikmesoft.nmsharekit.R;
import com.nikmesoft.nmsharekit.delegates.NMSKTwitterDialogDelegate;
import com.nikmesoft.nmsharekit.objects.NMShareMessage;
import com.nikmesoft.nmsharekit.objects.NMShareMessage.NMShareType;
import com.nikmesoft.nmsharekit.utils.NMSKTwitterSession;

public class NMSKTwitterDialog extends NMSKDialog {
	private NMSKTwitterDialogDelegate delegate;
	private NMShareMessage message;
	private EditText txtContent;
	private TextView tvUser;
	private ImageView shareImage;

	public NMSKTwitterDialog(Activity activity,
			NMSKTwitterDialogDelegate delegate, NMShareMessage message) {
		super(activity);
		// TODO Auto-generated constructor stub
		this.delegate = delegate;
		this.message = message;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_sharetwitter);
		initComponents();
		addListenner();
		txtContent.setSelection(txtContent.getText().length());
		tvUser.setText(NMSKTwitterSession.getInstance(activity).getUsername());
		InputFilter filter = new InputFilter.LengthFilter(
				message.getType() == NMShareType.NMShareTypeStory ? 140 - 27
						: 140);
		txtContent.setFilters(new InputFilter[] { filter });
	}

	@Override
	public void initComponents() {
		addNavigation("Twitter", R.drawable.ic_btn_cancel,
				R.drawable.ic_btn_post);
		txtContent = (EditText) findViewById(R.id.content);
		tvUser = (TextView) findViewById(R.id.tv_user);
		shareImage = (ImageView) findViewById(R.id.share_image);

		if (message.getMessage() != null || message.getMessage().length() > 0) {
			txtContent.setText(message.getMessage() + "\n");
		}
		if (message.getType() == NMShareType.NMShareTypeStory) {
			shareImage.setVisibility(View.VISIBLE);
			shareImage
					.setImageURI(Uri.fromFile(new File(message.getPicture())));
		}
	}

	@Override
	public void addListenner() {
		setBtnRightOnclickListenner(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();
				message.setMessage(txtContent.getText().toString());
				delegate.didSharedWithMessage(message);

			}
		});

		setBtnLeftOnclickListenner(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();
				delegate.cancel();

			}
		});
		txtContent.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				if (txtContent.getEditableText().toString().length() == 0) {

					changeBtnRight(R.drawable.ic_btn_post_disabled);
					disableBtnright(true);
				} else {
					changeBtnRight(R.drawable.ic_btn_post);
					disableBtnright(false);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

	public static void show(Activity activity,
			NMSKTwitterDialogDelegate delegate, NMShareMessage message) {
		NMSKTwitterDialog dialog = new NMSKTwitterDialog(activity,
				delegate, message);
		dialog.show();
	}
}
