package com.nikmesoft.nmsharekit.views;

import java.io.File;
import java.io.InputStream;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.nikmesoft.nmsharekit.R;
import com.nikmesoft.nmsharekit.delegates.NMSKFacebookDialogDelegate;
import com.nikmesoft.nmsharekit.objects.NMShareMessage;
import com.nikmesoft.nmsharekit.objects.NMShareMessage.NMShareType;
import com.nikmesoft.nmsharekit.utils.NMSKFacebookSession;
import com.nikmesoft.nmsharekit.utils.Utils;

public class NMSKFacebookDialog extends NMSKDialog {
	private NMSKFacebookDialogDelegate delegate;
	private EditText txtContent;
	private TextView tvUser;
	private View sharedContent;
	private ImageView sharedImage;
	private TextView sharedName, sharedCaption, sharedDescription;
	private NMShareMessage message;

	public NMSKFacebookDialog(Activity activity,
			NMSKFacebookDialogDelegate delegate, NMShareMessage message) {
		super(activity);
		this.delegate = delegate;
		this.message = message;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_sharefacebook);
		initComponents();
		addListenner();
		txtContent.setSelection(txtContent.getText().length());
		tvUser.setText(NMSKFacebookSession.getInstance(activity).getUsername());
	}

	@Override
	public void initComponents() {
		addNavigation("Facebook", R.drawable.ic_btn_cancel,
				R.drawable.ic_btn_post);
		txtContent = (EditText) findViewById(R.id.content);
		tvUser = (TextView) findViewById(R.id.tv_user);

		sharedContent = findViewById(R.id.layout_shared);
		sharedImage = (ImageView) findViewById(R.id.shared_image);
		sharedName = (TextView) findViewById(R.id.shared_name);
		sharedCaption = (TextView) findViewById(R.id.shared_caption);
		sharedDescription = (TextView) findViewById(R.id.shared_description);

		if (message.getType() == NMShareType.NMShareTypeStory) {

			if (message.getPicture() != null
					&& message.getPicture().length() > 0) {
				new DownloadImageTask(sharedImage)
						.execute(message.getPicture());
			} else {
				sharedImage.setVisibility(View.GONE);
			}
			sharedName.setText(message.getName());
			sharedCaption.setText(message.getCaption());
			sharedDescription.setText(message.getDescription());
		} else {
			txtContent.setMinHeight((int) activity.getResources().getDimension(
					R.dimen.defaultdl_editext_shared_minheight));
			if (message.getPicture() == null
					|| !new File(message.getPicture()).exists()) {
				sharedContent.setVisibility(View.GONE);
			} else {
				sharedImage.setImageBitmap(Utils.decodeSampledBitmapFromFile(
						message.getPicture(), 100, 100));
			}

		}
		if (message.getMessage() != null && message.getMessage().length() > 0) {
			// txtContent.setText(message.getMessage() + "\n");
		}

	}

	@Override
	public void addListenner() {
		setBtnRightOnclickListenner(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();
				message.setMessage(txtContent.getText().toString().trim());
				delegate.didSharedWithMessage(message);

			}
		});

		setBtnLeftOnclickListenner(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dismiss();
				delegate.cancel();

			}
		});
		txtContent.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				if (txtContent.getEditableText().toString().trim().length() == 0
						&& message.getType() == NMShareType.NMShareTypeStatus) {
					changeBtnRight(R.drawable.ic_btn_post_disabled);
					disableBtnright(true);
				} else {
					changeBtnRight(R.drawable.ic_btn_post);
					disableBtnright(false);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
	}

	public static void show(Activity activity,
			NMSKFacebookDialogDelegate delegate, NMShareMessage message) {
		NMSKFacebookDialog dialog = new NMSKFacebookDialog(activity, delegate,
				message);
		dialog.show();
	}

	@Override
	public void onClick(View v) {

	}

	private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
		ImageView bmImage;

		public DownloadImageTask(ImageView bmImage) {
			this.bmImage = bmImage;
		}

		protected Bitmap doInBackground(String... urls) {
			String urldisplay = urls[0];
			Bitmap bitmap = null;
			try {
				InputStream in = new java.net.URL(urldisplay).openStream();
				bitmap = BitmapFactory.decodeStream(in);
				in.close();
			} catch (Exception e) {
				// Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
			return bitmap;
		}

		protected void onPostExecute(Bitmap result) {
			if (result != null)
				bmImage.setImageBitmap(result);
		}
	}

	@Override
	public void cancel() {
		delegate.cancel();
		super.cancel();
	}
}
