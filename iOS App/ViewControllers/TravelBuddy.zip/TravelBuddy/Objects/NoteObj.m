//
//  NoteObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "NoteObj.h"

@implementation NoteObj
@synthesize noteId,title,dateTime,content,ownerUserId,tripId,serverId,flag,noteIcon,noteUrl;
@end
