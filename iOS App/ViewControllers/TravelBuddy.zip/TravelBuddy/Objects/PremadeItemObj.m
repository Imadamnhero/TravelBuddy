//
//  PremadeItemObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "PremadeItemObj.h"

@implementation PremadeItemObj
@synthesize itemId,itemName,listId,serverId,flag,isCheck;
@end
