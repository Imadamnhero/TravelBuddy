//
//  User.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "User.h"

@implementation User
@synthesize name,avatarUrl,userId,userInTripId,tripId,userIcon,isCheck;
@end
