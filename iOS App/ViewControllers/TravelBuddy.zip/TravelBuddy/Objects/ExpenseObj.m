//
//  ExpenseObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "ExpenseObj.h"

@implementation ExpenseObj
@synthesize expenseId,cateId,dateTime,money,item,ownerUserId,tripId,serverId,flag;
@end
