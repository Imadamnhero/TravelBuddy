//
//  PackingItemObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "PackingItemObj.h"

@implementation PackingItemObj
@synthesize itemId,itemName,isCheck,packingId,serverId,flag;
@end
