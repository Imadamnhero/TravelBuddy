//
//  VersionObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "VersionObj.h"

@implementation VersionObj
@synthesize versionId,noteVersion,categoryVersion,expenseVersion,groupVersion,photoVersion,packingTitleVersion,packingItemVersion,premadeListVersion,premadeItemVersion,userId,userVersion;
@end
