//
//  PremadeListObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "PremadeListObj.h"

@implementation PremadeListObj
@synthesize listId,title,serverId,flag,isCheck;
@end
