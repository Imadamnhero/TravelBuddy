//
//  TripObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "TripObj.h"

@implementation TripObj
@synthesize tripLocation,startDate,finishDate,budget,ownerUserId,tripId;
@end
