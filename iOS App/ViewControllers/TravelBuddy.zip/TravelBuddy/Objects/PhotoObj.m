//
//  PhotoObj.m
//  Fun Spot App
//
//  Created by MAC on 9/11/14.
//
//

#import "PhotoObj.h"

@implementation PhotoObj
@synthesize photoId,urlPhoto,caption,isReceipt,ownerUserId,tripId,serverId,flag,isChecked,tagPhoto;
@end
