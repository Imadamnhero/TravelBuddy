//
//  CreateSlideShowVC.m
//  Fun Spot App
//
//  Created by Tran Thanh Bang on 10/16/14.
//
//
#import "CreateSlideShowVC.h"
#import "SlideShowVC.h"
#import "AsynImageButton.h"
#import "PhotoViewController.h"
#import "BaseNavigationController.h"
#import "ImageGalleryViewController.h"
#import "CreateSlideShowVC.h"
#import "Annotation.h"
#import "PhotoObj.h"
#import "PlayListView.h"
#import "FileHelper.h"
@interface CreateSlideShowVC ()<UINavigationControllerDelegate,UIGestureRecognizerDelegate,AVAudioPlayerDelegate,AVAudioRecorderDelegate,AVAudioSessionDelegate,MPMediaPickerControllerDelegate,PlayListViewDelegate>
{
    __weak IBOutlet UILabel *_lbNameAudio;
    __weak IBOutlet UILabel *_lbDurationSlide;
    __weak IBOutlet UIView *_viewMenuBar;
    __weak IBOutlet UIButton *btnBack;
    __weak IBOutlet UIScrollView *_scrollImages;
    UIScrollView *_scrollerView;
    NSMutableArray *_images;
    UITapGestureRecognizer *recognizer;
    NSString *stringAudioCroped;
    NSURL *urlAudio;
    MPMediaItemCollection	*_userMediaItemCollection;
    PlayListView *_playListView;
    float screenHeightDevice;
    float audioDurationSeconds;
}

@end

@implementation CreateSlideShowVC
@synthesize arrayImages,musicPlayer;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self getScreenHeight];
    [self initData];
    [self initUI];
    [self getImage];
    //[self initializeMusicPlayer];
    //[self addMusicPlayerObserver];
    stringAudioCroped = [[NSBundle mainBundle]pathForResource:@"output11111" ofType:@"m4a"];
}
- (void)getScreenHeight
{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    screenHeightDevice = screenRect.size.height;
}
- (void)initData
{
    _images = [NSMutableArray array];
}
- (void)initUI
{
    btnBack.imageEdgeInsets = UIEdgeInsetsMake(8, 7, 7, 6);
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgScrollSlideShow.png"]];
}
- (void) getImage{
    arrayImages = [NSMutableArray array];
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    IMSSqliteManager *sqlManager = [[IMSSqliteManager alloc] init];
    @synchronized(self){
        arrayImages = [sqlManager getPhotoItems:[[userDefault objectForKey:@"userTripId"] intValue] andReceipt:0];
    }
    [self createScrollImageView];
}
- (void) createScrollImageView{
    for (UIView *subView in _scrollImages.subviews) {
        [subView removeFromSuperview];
    }
    float x = 0;
    float y = 5;
    _scrollImages.frame = CGRectMake(0, 40, self.view.frame.size.width, self.view.frame.size.height - 40 - 120);
    _scrollImages.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgScrollImages.png"]];
    for (int i = 0; i < arrayImages.count; i++) {
        PhotoObj *objPhoto = [[PhotoObj alloc] init];
        objPhoto = [arrayImages objectAtIndex:i];
        if (i % 3 == 0 ) {
            x = 5;
        }else
            x+= 105;
        y = 105*(i/3)+5;
        AsynImageButton *asynImgBtn = [[AsynImageButton alloc] initWithFrame:CGRectMake(x, y, 100, 100)];
        asynImgBtn.tag = TagImage+i;
        NSString *strImageName = [Common getFilePath:objPhoto.urlPhoto];
        NSData *pngData = [NSData dataWithContentsOfFile:strImageName];
        UIImage *image = [UIImage imageWithData:pngData];
        [asynImgBtn loadIMageFromImage:image];
        [asynImgBtn addTarget:self action:@selector(insertImage:) forControlEvents:UIControlEventTouchUpInside];
        [_scrollImages addSubview:asynImgBtn];
        
        UILabel *lblName = [[UILabel alloc] initWithFrame:CGRectMake(x, y+79, 100, 21)];
        lblName.backgroundColor = [UIColor blackColor];
        lblName.textColor = [UIColor whiteColor];
        lblName.text = objPhoto.caption;
        lblName.alpha = 0.6;
        lblName.font = [UIFont boldSystemFontOfSize:12];
        [_scrollImages addSubview:lblName];
        
        UIButton *btnSync = [[UIButton alloc] initWithFrame:CGRectMake(x+80, y+2, 20, 23)];
        [btnSync setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        btnSync.tag = TagImageClickSync+i;
        [_scrollImages addSubview:btnSync];
        if (objPhoto.isChecked == 0) {
            btnSync.hidden=YES;
        }
        else
            btnSync.hidden=NO;
    }
    [_scrollImages setContentSize:CGSizeMake(300, y+105)];
    _scrollImages.layer.borderColor = [UIColor darkGrayColor].CGColor;
    _viewMenuBar.frame = CGRectMake(0, _scrollImages.frame.origin.y + _scrollImages.frame.size.height, self.view.frame.size.width, 40);
}

- (void) insertImage:(id)sender{
    [self.view endEditing:YES];
    UIButton *btn = (UIButton *)sender;
    PhotoObj *photo = [arrayImages objectAtIndex:btn.tag-TagImage];
    if (photo.isChecked == 0) {
        photo.isChecked=1;
        for (UIView *subView in _scrollImages.subviews) {
            if (subView.tag == TagImageClickSync + (btn.tag-TagImage)) {
                subView.hidden=NO;
                [_images addObject:photo];
                
                break;
            }
        }
    }else
    {
        photo.isChecked=0;
        for (UIView *subView in _scrollImages.subviews) {
            if (subView.tag == TagImageClickSync + (btn.tag-TagImage)) {
                for (PhotoObj *ptObject in _images) {
                    if ([ptObject.urlPhoto isEqualToString:photo.urlPhoto]) {
                        [_images removeObject:ptObject];
                        break;
                    }
                }
                subView.hidden=YES;
                break;
            }
        }
    }
    [self calculationDurationOfSlide];
    [self createScrollView];
}
- (void)calculationDurationOfSlide
{
    float timeOfSlide = _images.count *3.0f;
    if (timeOfSlide >60) {
        int minutes = timeOfSlide/60;
        float seconds = fmodf(timeOfSlide, 60.0f);
        NSLog(@"====== :%i ==== seconds :%f",minutes,seconds);
        if (minutes>0) {
            if (seconds <10) {
                _lbDurationSlide.text = [NSString stringWithFormat:@"0%i:0%.0f",minutes,seconds];
            }
            else
            {
                _lbDurationSlide.text = [NSString stringWithFormat:@"0%i:%.0f",minutes,seconds];
            }
        }
        else
        {
            if (seconds <10) {
                _lbDurationSlide.text = [NSString stringWithFormat:@"00:0%.0f",seconds];
            }
            else
            {
                _lbDurationSlide.text = [NSString stringWithFormat:@"00:%.0f",seconds];
            }
        }
    }
    else
    {
        if (timeOfSlide <10) {
            _lbDurationSlide.text = [NSString stringWithFormat:@"00:0%.0f",timeOfSlide];
        }
        else
        {
            _lbDurationSlide.text = [NSString stringWithFormat:@"00:%.0f",timeOfSlide];
        }
    }
}
- (void)createScrollView
{
    for (UIView *subView in _scrollerView.subviews) {
        [subView removeFromSuperview];
    }
    _scrollerView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, _viewMenuBar.frame.origin.y + _viewMenuBar.frame.size.height, self.view.frame.size.width, self.view.frame.size.height - (_viewMenuBar.frame.origin.y + _viewMenuBar.frame.size.height ))];
    _scrollerView.backgroundColor = [UIColor clearColor];
    _scrollerView.indicatorStyle = UIScrollViewIndicatorStyleBlack;
    _scrollerView.showsHorizontalScrollIndicator = NO;
    _scrollerView.showsVerticalScrollIndicator = NO;
    _scrollerView.bounces = NO;
    
    NSLog(@"======= :%f",_scrollerView.frame.size.height);
    
    float x ;
    for(int i=0;i<_images.count;i++)
    {
        x = 10 + (_scrollerView.frame.size.height-15) *i;
        recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(addMorePhotos:)];
        recognizer.numberOfTouchesRequired = 1;
        recognizer.numberOfTapsRequired = 1;
        recognizer.delegate = self;
        UIImageView *bgImageView = [[UIImageView alloc]initWithFrame:CGRectMake(x, 10, _scrollerView.frame.size.height - 20, _scrollerView.frame.size.height - 20)];
        [bgImageView setTag:i];
        [bgImageView setUserInteractionEnabled:YES];
        PhotoObj *photo = [_images objectAtIndex:i];
        NSString *strImageName = [Common getFilePath:photo.urlPhoto];
        NSData *pngData = [NSData dataWithContentsOfFile:strImageName];
        UIImage *image = [UIImage imageWithData:pngData];
        bgImageView.image=image;
        [bgImageView addGestureRecognizer:recognizer];
        
        UIImageView *ImageViewDelete = [[UIImageView alloc]initWithFrame:CGRectMake(bgImageView.frame.size.width-15, 0, 15, 15)];
        [ImageViewDelete setTag:i];
        [ImageViewDelete setUserInteractionEnabled:YES];
        [ImageViewDelete addGestureRecognizer:recognizer];
        ImageViewDelete.image = [UIImage imageNamed:@"ic_delete.png"];
        [bgImageView addSubview:ImageViewDelete];
        [_scrollerView addSubview:bgImageView];
    }
    _scrollerView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgScrollSlideShow.png"]];
    _scrollerView.contentSize = CGSizeMake(x + (_scrollerView.frame.size.height-15), 80);
    [self.view addSubview:_scrollerView];
}
- (void)moveToLastObject
{
    CGPoint bottomOffset = CGPointMake(0, _images.count-1);
    [_scrollerView setContentOffset:bottomOffset animated:YES];
}
- (IBAction)addMorePhotos:(UITapGestureRecognizer *)sender
{
    NSLog(@"sender tag :%i",sender.view.tag);
    if (sender.view.tag == _images.count) {
        for (PhotoObj *photo in arrayImages) {
            photo.isChecked = 0;
        }
    }
    else
    {
        PhotoObj *photo = [_images objectAtIndex:sender.view.tag];
        [_images removeObjectAtIndex:sender.view.tag];
        for (PhotoObj *objPhoto in arrayImages) {
            if ([photo.urlPhoto isEqualToString:objPhoto.urlPhoto]) {
                objPhoto.isChecked = 0;
                break;
            }
        }
        [self createScrollView];
    }
    [self createScrollImageView];
    [self calculationDurationOfSlide];
    //import srcoll to bot in here.
}

#pragma mark - choose audio to create slide show
- (void)viewDidUnload
{
    [super viewDidUnload];
    [self removeMusicPlayerObserver];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

#pragma mark Music Player

- (void)initializeMusicPlayer {
    self.musicPlayer = [MPMusicPlayerController iPodMusicPlayer];
    [self.musicPlayer setShuffleMode:MPMusicShuffleModeOff];
    [self.musicPlayer setRepeatMode:MPMusicRepeatModeNone];
}


#pragma Add observer to Music Player state Notifications

- (void)addMusicPlayerObserver {
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleNowPlayingSongStateChanged:)
                                                 name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification
                                               object:self.musicPlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handlePlaybackStateChanged:)
                                                 name:MPMusicPlayerControllerPlaybackStateDidChangeNotification
                                               object:self.musicPlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleVolumeChangedFromOutSideApp:)
                                                 name:MPMusicPlayerControllerVolumeDidChangeNotification
                                               object:self.musicPlayer];
    [self.musicPlayer beginGeneratingPlaybackNotifications];
}


#pragma Remove obsever for Music Player Notifications

- (void)removeMusicPlayerObserver {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification
                                                  object:self.musicPlayer];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMusicPlayerControllerPlaybackStateDidChangeNotification
                                                  object:self.musicPlayer];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMusicPlayerControllerVolumeDidChangeNotification
                                                  object:self.musicPlayer];
    
    [self.musicPlayer endGeneratingPlaybackNotifications];
}

#pragma Music player Notification selectors

- (void)handleNowPlayingSongStateChanged:(id)notification {
    NSLog(@"handleNowPlayingSongStateChanged");
}


- (void)handlePlaybackStateChanged:(id)notification {
    
    NSLog(@"handlePlaybackStateChanged");
    
    MPMusicPlaybackState playbackState = self.musicPlayer.playbackState;
    
    if (playbackState == MPMusicPlaybackStatePaused || playbackState == MPMusicPlaybackStateStopped) {
        
    }else if (playbackState == MPMusicPlaybackStatePlaying) {
        
    }
}

- (void)handleVolumeChangedFromOutSideApp:(id)notification {
    
    NSLog(@"handleVolumeChangedFromOutSideApp");
}

#pragma Music Player Controls Methods


- (IBAction)playPauseMusic:(id)sender {
    
    MPMusicPlaybackState playbackState = self.musicPlayer.playbackState;
    
	if (playbackState == MPMusicPlaybackStateStopped || playbackState == MPMusicPlaybackStatePaused) {
		[self.musicPlayer play];
	} else if (playbackState == MPMusicPlaybackStatePlaying) {
        [self.musicPlayer pause];
    }
    
    
}
- (IBAction)createSlideShow:(id)sender {
    if (_images.count==0) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Travel buddy" message:@"Please choose your images" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [alert show];
    }
    else{
        [MBProgressHUD showHUDAddedTo:self.view WithTitle:@"creating..." animated:YES];
        if (urlAudio !=nil) {
            
            if (audioDurationSeconds/3<_images.count) {
                [self mergerAudio];
            }else{
                [self trimAudio:_images.count*3.0f];
            }
        }
        else
        {
            stringAudioCroped = [[NSBundle mainBundle]pathForResource:@"output11111" ofType:@"m4a"];
            urlAudio = [NSURL fileURLWithPath:stringAudioCroped];
            [self trimAudio:1.0f];
        }
    }
}

- (IBAction)selectSong:(id)sender {
    
    if (_images.count==0) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Travel Buddy" message:@"Please choose images to create slide show" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [alert show];
    }
    else
    {
        MPMediaPickerController *mediaPicker = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeAny];
        mediaPicker.delegate = self;
        [self presentModalViewController:mediaPicker animated:YES];
    }
}
#pragma mark MPMediaPickerController delegate methods

- (void)mediaPicker: (MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection
{
    MPMediaItem *item = [[mediaItemCollection items] objectAtIndex:0];
    _lbNameAudio.text = [item valueForProperty:MPMediaItemPropertyTitle];
    NSURL *url = [item valueForProperty:MPMediaItemPropertyAssetURL];
    urlAudio = url;
    AVURLAsset* audioAsset = [AVURLAsset URLAssetWithURL:url options:nil];
    CMTime audioDuration = audioAsset.duration;
    audioDurationSeconds = CMTimeGetSeconds(audioDuration);
    [self dismissModalViewControllerAnimated:YES];
    [self updateTheMediaColledtionsItems:mediaItemCollection];
}
- (void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker
{
    [self dismissModalViewControllerAnimated:YES];
}
- (void)updateTheMediaColledtionsItems:(MPMediaItemCollection *)mediaItemCollection {
    
    MPMediaItem * item = (MPMediaItem *)[mediaItemCollection.items objectAtIndex:0];
    NSURL * pathURL = [item valueForProperty:MPMediaItemPropertyAssetURL];
    urlAudio = pathURL;
    NSLog(@"PathURLAAAAAA :%@",urlAudio);
    if (_userMediaItemCollection == nil) {
        _userMediaItemCollection = mediaItemCollection;
        [self.musicPlayer setQueueWithItemCollection: _userMediaItemCollection];
        [self.musicPlayer play];
    } else  {
        BOOL wasPlaying = NO;
        if (self.musicPlayer.playbackState ==
            MPMusicPlaybackStatePlaying) {
            wasPlaying = YES;
        }
        
        MPMediaItem *nowPlayingItem	= self.musicPlayer.nowPlayingItem;
        NSTimeInterval currentPlaybackTime	= self.musicPlayer.currentPlaybackTime;
        NSMutableArray *currentSongsList= [[_userMediaItemCollection items] mutableCopy];
        NSArray *nowSelectedSongsList = [mediaItemCollection items];
        
        [currentSongsList addObjectsFromArray:nowSelectedSongsList];
        
        _userMediaItemCollection = [MPMediaItemCollection collectionWithItems:(NSArray *) currentSongsList];
        
        [self.musicPlayer setQueueWithItemCollection: _userMediaItemCollection];
        
        self.musicPlayer.nowPlayingItem	= nowPlayingItem;
        self.musicPlayer.currentPlaybackTime = currentPlaybackTime;
        [self.musicPlayer pause];
    }
}

#pragma mark - Merge audio
- (BOOL) mergerAudio
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    AVMutableComposition *composition = [[AVMutableComposition alloc] init];
    
    AVMutableCompositionTrack *compositionAudioTrack = [composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    [compositionAudioTrack setPreferredVolume:0.8];
    NSString *soundOne  =[[NSBundle mainBundle]pathForResource:@"30secs" ofType:@"mp3"];
    NSLog(@"====== :%@",soundOne);
    NSURL *url = urlAudio;
    AVAsset *avAsset = [AVURLAsset URLAssetWithURL:url options:nil];
    AVAssetTrack *clipAudioTrack = [[avAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];
    [compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, avAsset.duration) ofTrack:clipAudioTrack atTime:kCMTimeZero error:nil];
    
    AVMutableCompositionTrack *compositionAudioTrack1 = [composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    [compositionAudioTrack setPreferredVolume:0.3];
    NSString *soundOne1  =[[NSBundle mainBundle]pathForResource:@"30secs" ofType:@"mp3"];
    NSURL *url1 = urlAudio;
    AVAsset *avAsset1 = [AVURLAsset URLAssetWithURL:url1 options:nil];
    AVAssetTrack *clipAudioTrack1 = [[avAsset1 tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];
    [compositionAudioTrack1 insertTimeRange:CMTimeRangeMake(kCMTimeZero, avAsset.duration) ofTrack:clipAudioTrack1 atTime:kCMTimeZero error:nil];
    
    
    AVMutableCompositionTrack *compositionAudioTrack2 = [composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    [compositionAudioTrack2 setPreferredVolume:1.0];
    NSString *soundOne2  =[[NSBundle mainBundle]pathForResource:@"30secs" ofType:@"mp3"];
    NSURL *url2 = urlAudio;
    AVAsset *avAsset2 = [AVURLAsset URLAssetWithURL:url2 options:nil];
    AVAssetTrack *clipAudioTrack2 = [[avAsset2 tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];
    [compositionAudioTrack1 insertTimeRange:CMTimeRangeMake(kCMTimeZero, avAsset2.duration) ofTrack:clipAudioTrack2 atTime:kCMTimeZero error:nil];
    
    AVAssetExportSession *exportSession = [AVAssetExportSession
                                           exportSessionWithAsset:composition
                                           presetName:AVAssetExportPresetAppleM4A];
    if (nil == exportSession) return NO;
    
    NSString *soundOneNew = [documentsDirectory stringByAppendingPathComponent:@"combined10.m4a"];
    stringAudioCroped = soundOneNew;
    NSURL *urlSoundNew = [NSURL fileURLWithPath:soundOneNew];
    [[NSFileManager defaultManager] removeItemAtURL:urlSoundNew error:NULL];
    exportSession.outputURL = [NSURL fileURLWithPath:soundOneNew]; // output path
    exportSession.outputFileType = AVFileTypeAppleM4A; // output file type
    NSLog(@"OUT :%@",soundOneNew);
    // perform the export
    [exportSession exportAsynchronouslyWithCompletionHandler:^{
        
        if (AVAssetExportSessionStatusCompleted == exportSession.status) {
            NSLog(@"AVAssetExportSessionStatusCompleted");
            float timeEnd = _images.count *3.0f;
            [self trimAudio:timeEnd];
        } else if (AVAssetExportSessionStatusFailed == exportSession.status) {
            NSLog(@"AVAssetExportSessionStatusFailed");
        } else {
            NSLog(@"Export Session Status: %d", exportSession.status);
        }
    }];
    return YES;
}

#pragma mark - trim audio
- (void)trimAudio:(float)timeEnd
{
    
    NSURL *audioFileInput = urlAudio;
    // Path of your destination save audio file
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *libraryCachesDirectory = [paths objectAtIndex:0];
    
    NSString *strOutputFilePath = [libraryCachesDirectory stringByAppendingPathComponent:@"output.mov"];
    NSString *requiredOutputPath = [libraryCachesDirectory stringByAppendingPathComponent:@"output.m4a"];
    stringAudioCroped = requiredOutputPath;
    NSURL *audioFileOutput = [NSURL fileURLWithPath:requiredOutputPath];
    
    [[NSFileManager defaultManager] removeItemAtURL:audioFileOutput error:NULL];
    AVAsset *asset = [AVAsset assetWithURL:audioFileInput];
    
    AVAssetExportSession *exportSession = [AVAssetExportSession exportSessionWithAsset:asset
                                                                            presetName:AVAssetExportPresetAppleM4A];
    timeEnd = _images.count * 3.0f;
    
    float startTrimTime = 0.0f;
    float endTrimTime = timeEnd;
    
    CMTime startTime = CMTimeMake((int)(floor(startTrimTime * 100)), 100);
    CMTime stopTime = CMTimeMake((int)(ceil(endTrimTime * 100)), 100);
    CMTimeRange exportTimeRange = CMTimeRangeFromTimeToTime(startTime, stopTime);
    exportSession.outputURL = audioFileOutput;
    exportSession.outputFileType = AVFileTypeAppleM4A;
    exportSession.timeRange = exportTimeRange;
    
    [exportSession exportAsynchronouslyWithCompletionHandler:^
     {
         if (AVAssetExportSessionStatusCompleted == exportSession.status)
         {
             NSLog(@"Success!");
             NSLog(@" OUtput path is \n %@", requiredOutputPath);
             stringAudioCroped = requiredOutputPath;
             NSFileManager * fm = [[NSFileManager alloc] init];
             [fm moveItemAtPath:strOutputFilePath toPath:requiredOutputPath error:nil];
             [self createVideo];
         }
         
         else if (AVAssetExportSessionStatusFailed == exportSession.status)
         {
             
             NSLog(@"failed %@", exportSession.error.localizedDescription);
         }
     }];
}
-(UIImage*)imageWithImage: (UIImage*) sourceImage scaledToWidth: (float) i_width
{
    float oldWidth = sourceImage.size.width;
    float oldHeight = sourceImage.size.height;
    float scaleFactor = i_width / oldWidth;
    float tyle = sourceImage.size.width/sourceImage.size.height;
    NSLog(@"====Ty le :%f",sourceImage.size.width/sourceImage.size.height);
    
    float newHeight = sourceImage.size.height * scaleFactor;
    float newWidth = oldWidth * scaleFactor;
    
    UIGraphicsBeginImageContext(CGSizeMake(newWidth, newHeight));
    [sourceImage drawInRect:CGRectMake(0, 0, newWidth, newHeight)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
- (void)createVideo {
    
    NSError *error = nil;
    // set up file manager, and file videoOutputPath, remove "test_output.mp4" if it exists...
    //NSString *videoOutputPath = @"/Users/someuser/Desktop/test_output.mp4";
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    NSString *documentsDirectory = [NSHomeDirectory()
                                    stringByAppendingPathComponent:@"Documents"];
    NSString *videoOutputPath = [documentsDirectory stringByAppendingPathComponent:@"test_output.mp4"];
    //NSLog(@"-->videoOutputPath= %@", videoOutputPath);
    // get rid of existing mp4 if exists...
    if ([fileMgr removeItemAtPath:videoOutputPath error:&error] != YES)
        NSLog(@"Unable to delete file: %@", [error localizedDescription]);
    
    
    CGSize imageSize = CGSizeMake(480, 400);
    NSUInteger fps = 30;
    
    
    //NSMutableArray *imageArray;
    //imageArray = [[NSMutableArray alloc] initWithObjects:@"download.jpeg", @"download2.jpeg", nil];
    NSMutableArray *imageArray;
    NSArray* imagePaths = [[NSBundle mainBundle] pathsForResourcesOfType:@"jpg" inDirectory:nil];
    imageArray = [[NSMutableArray alloc] initWithCapacity:imagePaths.count];
    NSLog(@"-->imageArray.count= %i", imageArray.count);
    
    for (PhotoObj *slide in _images) {
        
        NSString *strImageName = [Common getFilePath:slide.urlPhoto];
        NSData *pngData = [NSData dataWithContentsOfFile:strImageName];
        UIImage *image = [UIImage imageWithData:pngData];
        //        UIImage *imageScaled;
        //        imageScaled = [self imageWithImage:image scaledToWidth:480.f];
        float oldWidth = image.size.height;
        float oldHeight = image.size.height;
        float rateOfImage = (oldWidth/oldHeight);
        float newHeight = 480/rateOfImage;
        CGRect rect = CGRectMake(0,0,480,400);
        UIGraphicsBeginImageContext( rect.size );
        [image drawInRect:rect];
        UIImage *picture1 = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        NSData *imageData = UIImagePNGRepresentation(picture1);
        UIImage *img=[UIImage imageWithData:imageData];
        [imageArray addObject:img];
    }
    
    //////////////     end setup    ///////////////////////////////////
    
    NSLog(@"Start building video from defined frames.");
    
    AVAssetWriter *videoWriter = [[AVAssetWriter alloc] initWithURL:
                                  [NSURL fileURLWithPath:videoOutputPath] fileType:AVFileTypeQuickTimeMovie
                                                              error:&error];
    NSParameterAssert(videoWriter);
    
    NSDictionary *videoSettings = [NSDictionary dictionaryWithObjectsAndKeys:
                                   AVVideoCodecH264, AVVideoCodecKey,
                                   [NSNumber numberWithInt:imageSize.width], AVVideoWidthKey,
                                   [NSNumber numberWithInt:imageSize.height], AVVideoHeightKey,
                                   nil];
    
    AVAssetWriterInput* videoWriterInput = [AVAssetWriterInput
                                            assetWriterInputWithMediaType:AVMediaTypeVideo
                                            outputSettings:videoSettings];
    
    
    AVAssetWriterInputPixelBufferAdaptor *adaptor = [AVAssetWriterInputPixelBufferAdaptor
                                                     assetWriterInputPixelBufferAdaptorWithAssetWriterInput:videoWriterInput
                                                     sourcePixelBufferAttributes:nil];
    
    NSParameterAssert(videoWriterInput);
    NSParameterAssert([videoWriter canAddInput:videoWriterInput]);
    videoWriterInput.expectsMediaDataInRealTime = YES;
    [videoWriter addInput:videoWriterInput];
    
    //Start a session:
    [videoWriter startWriting];
    [videoWriter startSessionAtSourceTime:kCMTimeZero];
    
    CVPixelBufferRef buffer = NULL;
    
    //convert uiimage to CGImage.
    int frameCount = 0;
    double numberOfSecondsPerFrame = 3;
    double frameDuration = fps * numberOfSecondsPerFrame;
    
    //for(VideoFrame * frm in imageArray)
    NSLog(@"**************************************************");
    for(UIImage * img in imageArray)
    {
        //UIImage * img = frm._imageFrame;
        buffer = [self pixelBufferFromCGImage:[img CGImage]];
        
        BOOL append_ok = NO;
        int j = 0;
        while (!append_ok && j < 30) {
            if (adaptor.assetWriterInput.readyForMoreMediaData)  {
                //print out status:
                NSLog(@"Processing video frame (%d,%d)",frameCount,[imageArray count]);
                
                CMTime frameTime = CMTimeMake(frameCount*frameDuration,(int32_t) fps);
                append_ok = [adaptor appendPixelBuffer:buffer withPresentationTime:frameTime];
                if(!append_ok){
                    NSError *error = videoWriter.error;
                    if(error!=nil) {
                        NSLog(@"Unresolved error %@,%@.", error, [error userInfo]);
                    }
                }
            }
            else {
                printf("adaptor not ready %d, %d\n", frameCount, j);
                [NSThread sleepForTimeInterval:0.1];
            }
            j++;
        }
        if (!append_ok) {
            printf("error appending image %d times %d\n, with error.", frameCount, j);
        }
        frameCount++;
    }
    NSLog(@"**************************************************");
    
    //Finish the session:
    [videoWriterInput markAsFinished];
    [videoWriter finishWriting];
    NSLog(@"Write Ended");
    
    ////////////////////////////////////////////////////////////////////////////
    //////////////  OK now add an audio file to move file  /////////////////////
    AVMutableComposition* mixComposition = [AVMutableComposition composition];
    
    if (stringAudioCroped.length <10) {
        stringAudioCroped  =[[NSBundle mainBundle]pathForResource:@"output11111" ofType:@"m4a"];
        NSLog(@"STRING AUDIO :%@",stringAudioCroped);
    }
    printf("mixComposition ending %d times \n, ", 1);
    
    NSURL    *audio_inputFileUrl = [NSURL fileURLWithPath:stringAudioCroped];
    NSURL    *video_inputFileUrl = [NSURL fileURLWithPath:videoOutputPath];
    // this is the video file that was just written above, full path to file is in --> videoOutputPath
    
    // create the final video output file as MOV file - may need to be MP4, but this works so far...
    NSString *tripId = [[NSUserDefaults standardUserDefaults]objectForKey:@"userTripId"];
    NSString *timeStamp = [self timeStamp];
    NSString *fileNameVideoSave=[NSString stringWithFormat:@"video_%@_%@.mp4",tripId,timeStamp];
    NSString *outputFilePath = [FileHelper videoPathForName:fileNameVideoSave];
//    NSString *outputFilePath = [documentsDirectory stringByAppendingPathComponent:@"final_video.mp4"];
    NSURL    *outputFileUrl = [NSURL fileURLWithPath:outputFilePath];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:outputFilePath])
        [[NSFileManager defaultManager] removeItemAtPath:outputFilePath error:nil];

    CMTime nextClipStartTime = kCMTimeZero;
    
    AVURLAsset* videoAsset = [[AVURLAsset alloc]initWithURL:video_inputFileUrl options:nil];
    CMTimeRange video_timeRange = CMTimeRangeMake(kCMTimeZero,videoAsset.duration);
    AVMutableCompositionTrack *a_compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
    [a_compositionVideoTrack insertTimeRange:video_timeRange ofTrack:[[videoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0] atTime:nextClipStartTime error:nil];
    
    //nextClipStartTime = CMTimeAdd(nextClipStartTime, a_timeRange.duration);
    
    AVURLAsset* audioAsset = [[AVURLAsset alloc]initWithURL:audio_inputFileUrl options:nil];
    CMTimeRange audio_timeRange = CMTimeRangeMake(kCMTimeZero, audioAsset.duration);
    AVMutableCompositionTrack *b_compositionAudioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    [b_compositionAudioTrack insertTimeRange:audio_timeRange ofTrack:[[audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0] atTime:nextClipStartTime error:nil];
    
    
    AVAssetExportSession* _assetExport = [[AVAssetExportSession alloc] initWithAsset:mixComposition presetName:AVAssetExportPresetHighestQuality];
    //_assetExport.outputFileType = @"com.apple.quicktime-movie";
    _assetExport.outputFileType = @"public.mpeg-4";
    //NSLog(@"support file types= %@", [_assetExport supportedFileTypes]);
    _assetExport.outputURL = outputFileUrl;
    
    [_assetExport exportAsynchronouslyWithCompletionHandler:
     ^(void ) {
         [self exportDidFinish:_assetExport];
     }
     ];
    
    ///// THAT IS IT DONE... the final video file will be written here...
    NSLog(@"DONE.....outputFilePath--->%@", outputFilePath);
    
    // the final video file will be located somewhere like here:
    // /Users/caferrara/Library/Application Support/iPhone Simulator/6.0/Applications/D4B12FEE-E09C-4B12-B772-7F1BD6011BE1/Documents/outputFile.mov
    
    
    ////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
}
- (NSString *) timeStamp {
    return [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000];
}

#pragma mark - Save video to library
- (void)exportDidFinish:(AVAssetExportSession*)session
{
    if(session.status == AVAssetExportSessionStatusCompleted){
        NSURL *outputURL = session.outputURL;
        NSLog(@"URL :%@",outputURL);
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        if ([library videoAtPathIsCompatibleWithSavedPhotosAlbum:outputURL]) {
            [library writeVideoAtPathToSavedPhotosAlbum:outputURL
                                        completionBlock:^(NSURL *assetURL, NSError *error){
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                if (error) {
                                                    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                                                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Video Saving Failed"  delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil, nil];
                                                    [alert show];
                                                    
                                                }else{
                                                    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                                                    [self playVedio:outputURL];
                                                }
                                            });
                                        }];
        }
    }
}

- (void)writeDataToFile:(NSMutableString *)stringInPut
{
    NSMutableString *printString = [NSMutableString stringWithString:@""];
    
    //CREATE FILE
    
    NSError *error;
    
    // Create file manager
    //NSFileManager *fileMgr = [NSFileManager defaultManager];
    
    NSString *documentsDirectory = [NSHomeDirectory()
                                    stringByAppendingPathComponent:@"Documents"];
    
    NSString *filePath = [documentsDirectory
                          stringByAppendingPathComponent:@"fileArray.txt"];
    
    NSLog(@"string to write:%@",printString);
    // Write to the file
    [printString writeToFile:filePath atomically:YES
                    encoding:NSUTF8StringEncoding error:&error];
}

-(void)playVedio:(NSURL*)moviePath{
    mp = [[MPMoviePlayerViewController alloc] initWithContentURL:moviePath];
    
    [[mp moviePlayer] prepareToPlay];
    [[mp moviePlayer] setUseApplicationAudioSession:NO];
    [[mp moviePlayer] setShouldAutoplay:YES];
    [[mp moviePlayer] setControlStyle:2];
    [[mp moviePlayer] setRepeatMode:MPMovieRepeatModeOne];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayBackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    [self presentMoviePlayerViewControllerAnimated:mp];
    
}

-(void)videoPlayBackDidFinish:(NSNotification*)notification  {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    
    [mp.moviePlayer stop];
    mp = nil;
    [self dismissMoviePlayerViewControllerAnimated];
}

- (CVPixelBufferRef) pixelBufferFromCGImage: (CGImageRef) image size:(CGSize)size {
    
    //CGSize size = CGSizeMake(320,480);
    
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGImageCompatibilityKey,
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGBitmapContextCompatibilityKey,
                             nil];
    CVPixelBufferRef pxbuffer = NULL;
    
    CVReturn status = CVPixelBufferCreate(kCFAllocatorDefault,
                                          size.width,
                                          size.height,
                                          kCVPixelFormatType_32ARGB,
                                          (__bridge CFDictionaryRef) options,
                                          &pxbuffer);
    if (status != kCVReturnSuccess){
        NSLog(@"Failed to create pixel buffer");
    }
    
    CVPixelBufferLockBaseAddress(pxbuffer, 0);
    void *pxdata = CVPixelBufferGetBaseAddress(pxbuffer);
    
    CGColorSpaceRef rgbColorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pxdata, size.width,
                                                 size.height, 8, 4*size.width, rgbColorSpace,
                                                 kCGImageAlphaPremultipliedFirst);
    //kCGImageAlphaNoneSkipFirst);
    CGContextConcatCTM(context, CGAffineTransformMakeRotation(0));
    CGContextDrawImage(context, CGRectMake(0, 0, CGImageGetWidth(image),
                                           CGImageGetHeight(image)), image);
    CGColorSpaceRelease(rgbColorSpace);
    CGContextRelease(context);
    
    CVPixelBufferUnlockBaseAddress(pxbuffer, 0);
    
    return pxbuffer;
}

////////////////////////
- (CVPixelBufferRef) pixelBufferFromCGImage: (CGImageRef) image {
    CGSize size = CGSizeMake(480,400);
    
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGImageCompatibilityKey,
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGBitmapContextCompatibilityKey,
                             nil];
    CVPixelBufferRef pxbuffer = NULL;
    
    CVReturn status = CVPixelBufferCreate(kCFAllocatorDefault,
                                          size.width,
                                          size.height,
                                          kCVPixelFormatType_32ARGB,
                                          (__bridge CFDictionaryRef) options,
                                          &pxbuffer);
    if (status != kCVReturnSuccess){
        NSLog(@"Failed to create pixel buffer");
    }
    
    CVPixelBufferLockBaseAddress(pxbuffer, 0);
    void *pxdata = CVPixelBufferGetBaseAddress(pxbuffer);
    
    CGColorSpaceRef rgbColorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pxdata, size.width,
                                                 size.height, 8, 4*size.width, rgbColorSpace,
                                                 kCGImageAlphaPremultipliedFirst);
    //kCGImageAlphaNoneSkipFirst);
    CGContextConcatCTM(context, CGAffineTransformMakeRotation(0));
    CGContextDrawImage(context, CGRectMake(0, 0, CGImageGetWidth(image),
                                           CGImageGetHeight(image)), image);
    CGColorSpaceRelease(rgbColorSpace);
    CGContextRelease(context);
    
    CVPixelBufferUnlockBaseAddress(pxbuffer, 0);
    
    return pxbuffer;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
- (IBAction)backToSlideShowVC:(id)sender {
    arrayImages = [NSMutableArray array];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
