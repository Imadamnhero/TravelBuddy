//
//  CreateSlideShowVC.h
//  Fun Spot App
//
//  Created by Tran Thanh Bang on 10/16/14.
//
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreGraphics/CoreGraphics.h>
#import <AVFoundation/AVFoundation.h>
#import <QuartzCore/QuartzCore.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AssetsLibrary/AssetsLibrary.h>
@interface CreateSlideShowVC : UIViewController<MPMediaPickerControllerDelegate>
{
    MPMoviePlayerController *moviePlayer;
    MPMoviePlayerViewController *mp;
}
@property (nonatomic,strong) MPMusicPlayerController *musicPlayer;
@property (nonatomic,strong)NSMutableArray *arrayImages;
@end
