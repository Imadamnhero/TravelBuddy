//
//  SlideShowVC.m
//  Fun Spot App
//
//  Created by MAC on 8/29/14.
//
//

#import "SlideShowVC.h"
#import "AsynImageButton.h"
#import "PhotoViewController.h"
#import "BaseNavigationController.h"
#import "ImageGalleryViewController.h"
#import "CreateSlideShowVC.h"
#import "Annotation.h"
#import "PhotoObj.h"
#import "FileHelper.h"
#import "SlideVideo.h"
@interface SlideShowVC (){
    NSString *urlShareSlideShow;
}

@end

@implementation SlideShowVC
@synthesize mainArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    float main_top = 0;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        main_top = 0;
    }
    CGRect mainRect = [[UIScreen mainScreen] bounds];
    self.itemsView = [[UIView alloc] initWithFrame:CGRectMake(-self.view.frame.size.width, main_top, self.view.frame.size.width-200, mainRect.size.height-main_top)];
    self.itemsView.hidden = YES;
    [self.view addSubview:self.itemsView];
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(mapLongPress:)];
    longPressGesture.minimumPressDuration = 1.5;
    [mapView addGestureRecognizer:longPressGesture];
    mainArray = [[NSMutableArray alloc] init];
    arrayFilePathVideos = [NSMutableArray array];
    arrayFilePathSaved = [NSMutableArray array];
    [self getImage];
}
- (void) getImage{
    [mainArray removeAllObjects];
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    IMSSqliteManager *sqlManager = [[IMSSqliteManager alloc] init];
    @synchronized(self){
        mainArray = [sqlManager getPhotoItems:[[userDefault objectForKey:@"userTripId"] intValue] andReceipt:0];
    }
    [self reloadScrollView];
}
- (void) reloadScrollView{
    for (UIView *subView in mainScroll.subviews) {
        [subView removeFromSuperview];
    }
    float x = 0;
    float y = 5;
    for (int i = 0; i < mainArray.count; i++) {
        PhotoObj *objPhoto = [[PhotoObj alloc] init];
        objPhoto = [mainArray objectAtIndex:i];
        if (i % 3 == 0 ) {
            x = 5;
        }else
            x+= 105;
        y = 105*(i/3)+5;
        AsynImageButton *asynImgBtn = [[AsynImageButton alloc] initWithFrame:CGRectMake(x, y, 100, 100)];
        asynImgBtn.tag = TagImage+i;
        NSString *strImageName = [Common getFilePath:objPhoto.urlPhoto];
        NSData *pngData = [NSData dataWithContentsOfFile:strImageName];
        UIImage *image = [UIImage imageWithData:pngData];
        [asynImgBtn loadIMageFromImage:image];
        //        [asynImgBtn setImage:[UIImage imageNamed:strImageName] forState:UIControlStateNormal];
        [asynImgBtn addTarget:self action:@selector(pushToGallery:) forControlEvents:UIControlEventTouchUpInside];
        [mainScroll addSubview:asynImgBtn];
        
        UILabel *lblName = [[UILabel alloc] initWithFrame:CGRectMake(x, y+79, 100, 21)];
        lblName.backgroundColor = [UIColor blackColor];
        lblName.textColor = [UIColor whiteColor];
        lblName.text = objPhoto.caption;
        lblName.alpha = 0.6;
        lblName.font = [UIFont boldSystemFontOfSize:12];
        [mainScroll addSubview:lblName];
        
        if (objPhoto.serverId == 0) {
            UIButton *btnSync = [[UIButton alloc] initWithFrame:CGRectMake(x+69, y+2, 28, 28)];
            [btnSync setImage:[UIImage imageNamed:@"ic_upload.png"] forState:UIControlStateNormal];
            [btnSync setImage:[UIImage imageNamed:@"ic_upload_clicked.png"] forState:UIControlStateHighlighted];
            btnSync.tag = TagImageClickSync+i;
            [btnSync addTarget:self action:@selector(syncPhoto:) forControlEvents:UIControlEventTouchUpInside];
            [mainScroll addSubview:btnSync];
        }
        
    }
    [mainScroll setContentSize:CGSizeMake(300, y+105)];
    mainScroll.layer.borderColor = [UIColor darkGrayColor].CGColor;
}

- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = YES;
    scrollChooseVideo.frame = CGRectMake(0, self.view.frame.size.height, scrollChooseVideo.frame.size.width, scrollChooseVideo.frame.size.height);
    mainScroll.hidden = NO;
    scrollChooseVideo.hidden=YES;
    scrollPreviews.hidden=YES;
    btnDone.hidden=YES;
    viewSharing.hidden=YES;
}

- (void)mapLongPress:(UILongPressGestureRecognizer *)gestureRecognizer{
    if(gestureRecognizer.state == UIGestureRecognizerStateBegan){
        CGPoint touchLocation = [gestureRecognizer locationInView:mapView];
        
        CLLocationCoordinate2D coordinate;
        coordinate = [mapView convertPoint:touchLocation toCoordinateFromView:mapView];// how to convert this to a String or something else?
        NSLog(@"Longpress");
    }
}

// Show location Sanfrancisco
- (void)showUserLocation
{
	MKCoordinateRegion region;
	MKCoordinateSpan span;
	span.latitudeDelta=0.02;
	span.longitudeDelta=0.02;
	
	CLLocationCoordinate2D location;
	location.latitude = 37.774929500000000000;
	location.longitude = -122.419415500000010000;
	
	region.span=span;
	region.center=location;
	
	Annotation *ann = [[Annotation alloc] init];
	ann.title =  @"";
    
	ann.subtitle = @"";
	ann.coordinate = region.center;
	[mapView addAnnotation:ann];
	
	[mapView setRegion:region animated:TRUE];
	[mapView regionThatFits:region];
}
- (void)mapView:(MKMapView *)mapView didLongPressAtCoordinate:(CLLocationCoordinate2D)coordinate{
    NSLog(@"%f",coordinate.latitude);
    NSLog(@"%f",coordinate.longitude);
}
-(void) afterClickSyncPhoto:(PhotoObj*)obj withTag:(int)tag{
    NSLog(@"obj.caption :%@",obj.caption);
    IMSSqliteManager *sqliteManager = [[IMSSqliteManager alloc] init];
    VersionObj *objVersion = [[VersionObj alloc] init];
    int photoIdDeleted = -1;
    @synchronized(self)
    {
        objVersion = [[sqliteManager getVersion] objectAtIndex:0];
    }
    
    if (obj.flag == 0) {
        return;
    }
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:30];
    [request setHTTPMethod:@"POST"];
    //flag(=1), client_ver, ownerid, photourl, isreceipt(=0,=1), caption, clientid
    NSMutableDictionary* _params = [[NSMutableDictionary alloc] init];
    [_params setObject:[NSNumber numberWithInt:obj.photoId] forKey:@"clientid"];
    [_params setObject:[NSNumber numberWithInt:objVersion.photoVersion] forKey:@"client_ver"];
    [_params setObject:[NSNumber numberWithInt:obj.ownerUserId] forKey:@"ownerid"];
    [_params setObject:[NSNumber numberWithInt:obj.flag] forKey:@"flag"];
    if (obj.flag == 3) {
        photoIdDeleted = obj.photoId;
        [_params setObject:[NSNumber numberWithInt:obj.serverId] forKey:@"serverid"];
    }else{
        [_params setObject:obj.caption forKey:@"caption"];
        [_params setObject:[NSNumber numberWithInt:obj.isReceipt] forKey:@"isreceipt"];
    }
    //- Commit ảnh và update data, có input: flag(=1), client_ver, ownerid, photourl, isreceipt(=0,=1), caption, clientid
    NSString *BoundaryConstant = @"V2ymHFg03ehbqgZCaKO6jy";
    
    // string constant for the post parameter 'file'
    NSString *FileParamConstant = @"";
    if (obj.flag != 3)
        FileParamConstant = @"photourl";
    
    //Setup request URL
    NSURL *requestURL = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"%@/sync_photo.php",SERVER_LINK]];
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", BoundaryConstant];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    for (NSString *param in _params) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", param] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", [_params objectForKey:param]] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    if (obj.flag != 3) {
        // add image data
        NSString *strImageName = [Common getFilePath:obj.urlPhoto];
        NSData *imageData = [NSData dataWithContentsOfFile:strImageName];
        if (imageData) {
            printf("appending image data\n");
            [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\'%@\'; filename=\"images.png\"\r\n", FileParamConstant] dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:imageData];
            [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%d", [body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    // set URL
    [request setURL:requestURL];
    
    NSURLResponse *response = nil;
    NSError *error=nil;
    NSData *data=[[NSData alloc] initWithData:[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error]];
    
    NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    NSLog(@"sync photo : %@",dict);
    if ([[dict objectForKey:@"success"] intValue] == 0) {
        if (![[dict objectForKey:@"message"] isEqualToString:@""]) {
            //                    [delegate showAlert:[dict objectForKey:@"message"]];
        }
    }else{
        //update expense version in table Versions
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            // Main thread work (UI usually)
            @synchronized(self)
            {
                int newVersion = [[dict objectForKey:@"new_ver"] intValue];
                objVersion.photoVersion = newVersion;
                [sqliteManager updateVersion:objVersion];
            }
        }];
        
        //update information for record in local which updated on server
        NSDictionary *dictCommitted = [dict objectForKey:@"committed_id"];
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            // Main thread work (UI usually)
            @synchronized(self)
            {
                int clientId = [[dictCommitted objectForKey:@"clientid"] intValue];
                int serverId = [[dictCommitted objectForKey:@"serverid"] intValue];
                [Common removeImage:obj.urlPhoto];
                if (photoIdDeleted >0) {
                    NSLog(@"delete image");
                    [sqliteManager deletePhoto:clientId];
                }else{
                    NSString *imageName = [[dictCommitted objectForKey:@"photourl"] stringByReplacingOccurrencesOfString:@"/" withString:@""];
                    [sqliteManager updatePhotoFromServer:clientId withServerId:serverId];
                    [Common saveImageToLocal:[dictCommitted objectForKey:@"photourl"]];
                    [sqliteManager updatePhotoUrlFromServer:clientId withPhotoUrl:imageName];
                    obj.serverId = serverId;
                    obj.urlPhoto = imageName;
                }
            }
            for (UIView *subView in mainScroll.subviews) {
                if (subView.tag == tag) {
                    NSLog(@"subView.tag: %d",subView.tag);
                    NSLog(@"tag: %d",tag);
                    [subView removeFromSuperview];
                }
            }
        }];
        
        //get array updated from sever
        NSMutableArray *arrayUpdateData = [[NSMutableArray alloc] init];
        arrayUpdateData = [dict objectForKey:@"updated_data"];
        for (int j = 0 ; j < arrayUpdateData.count; j++) {
            PhotoObj *objPhoto = [[PhotoObj alloc] init];
            NSMutableDictionary *dictResponse = [arrayUpdateData objectAtIndex:j];
            
            objPhoto.caption  = [dictResponse objectForKey:@"caption"];
            NSString *imageName = [[dictResponse objectForKey:@"photourl"] stringByReplacingOccurrencesOfString:@"/" withString:@""];
            objPhoto.urlPhoto = imageName;
            objPhoto.isReceipt = [[dictResponse objectForKey:@"isreceipt"] intValue];
            objPhoto.tripId = [[dictResponse objectForKey:@"tripid"] intValue];
            objPhoto.ownerUserId = [[dictResponse objectForKey:@"ownerid"] intValue];
            objPhoto.serverId    = [[dictResponse objectForKey:@"serverid"] intValue];
            objPhoto.flag        = 0;
            
            if ([[dictResponse objectForKey:@"flag"] intValue] == 1) {
                [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                    // Main thread work (UI usually)
                    @synchronized(self)
                    {
                        [sqliteManager addPhotoInfor:objPhoto];
                        [Common saveImageToLocal:[dictResponse objectForKey:@"photourl"]];
                    }
                }];
            }
        }
    }
}

-(void) syncPhoto:(id)sender{
    UIButton *btn = (UIButton *)sender;
    btn.hidden = YES;
    int tag = btn.tag - TagImageClickSync;
    for (UIView *subView in mainScroll.subviews) {
        if (subView.tag == (tag + TagImage)) {
            UIActivityIndicatorView *actIn = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(subView.frame.origin.x+35, subView.frame.origin.y+35, 30, 30)];
            [actIn startAnimating];
            actIn.tag = TagActIn + tag;
            [mainScroll addSubview:actIn];
        }
    }
    //Get current Photo which want to update
    PhotoObj *obj = [[PhotoObj alloc] init];
    obj = [mainArray objectAtIndex:tag];
    
    [delegate.myQueue addOperationWithBlock:^{
        
        // Background work
        [self afterClickSyncPhoto:obj withTag:(TagActIn + tag)];
    }];
}
// push to gallery
-(void) pushToGallery:(id)sender{
    UIButton *btn = (UIButton *)sender;
    ImageGalleryViewController *imageGallery = [[ImageGalleryViewController alloc] initWithNibName:@"ImageGalleryViewController" bundle:nil parent:self];
    self.navigationItem.title =@"Back";
    imageGallery.isSlideshow = true;
    [[self navigationController] pushViewController:imageGallery animated:YES];
    imageGallery.currentPage = btn.tag - TagImage;
    
    return;
    
    //===========================================
    PhotoViewController *pageZero = [PhotoViewController photoViewControllerForPageIndex:0 withArray:mainArray];
    //    if (pageZero != nil) {
    // assign the first page to the pageViewController (our rootViewController)
    UIPageViewController *pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    pageViewController.dataSource = self;
    pageViewController.automaticallyAdjustsScrollViewInsets = NO;
    
    [pageViewController setViewControllers:@[pageZero]
                                 direction:UIPageViewControllerNavigationDirectionForward
                                  animated:NO
                                completion:NULL];
    
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:pageViewController];
    pageZero.title =@"Gallery";
    
    pageViewController.navigationItem.title  = @"Gallery";
    
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(dismissScreen:)];
    pageViewController.navigationItem.rightBarButtonItem = doneBtn;
    
    [self.navigationController presentViewController:navController animated:YES completion:nil];
    //    }
}
- (void)dismissScreen :(id)sender{
    //    [self.mapView setDelegate:nil];
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnHomeClick:(id)sender {
    if (self.itemsView.hidden) {
        self.itemsView.hidden = NO;
        [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:YES delegate:self rect:self.itemsView.frame selected:@""];
        
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = 0;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];
    } else {
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = -rect.size.width;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             self.itemsView.hidden = YES;
                             [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:NO delegate:self rect:self.itemsView.frame selected:@""];
                         }];
    }
}

- (IBAction)btnCreateClick:(id)sender {
    if (mainArray.count==0) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Travel Buddy" message:@"Please add photo to create slide show" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [alert show];
    }
    else{
        CreateSlideShowVC *createVC = [[CreateSlideShowVC alloc]initWithNibName:@"CreateSlideShowVC" bundle:nil];
        createVC.arrayImages = [mainArray copy];
        [self.navigationController pushViewController:createVC animated:YES];
    }
}
-(void)createSlideShow{
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    subViewCreateSlide.hidden = NO;
}
#pragma mark preview in here
- (IBAction)btnPreviewClick:(id)sender {
    arrayFilePathVideos = [NSMutableArray array];
    
    [self scanPath:[FileHelper videoDirectory]];
    if (arrayFilePathVideos.count==0) {
        [delegate showAlert:@"Please create slide show"];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }else{
        
        scrollPreviews.frame = mainScroll.frame;
        mainScroll.hidden = YES;
        scrollPreviews.hidden=NO;
        scrollChooseVideo.hidden=YES;
        btnDone.hidden=YES;
        scrollPreviews.backgroundColor = [UIColor grayColor];
        [self loadVideoSlideShow];
    }
}
#pragma mark load all video to scroll view
//load all url video in path
- (void)scanPath:(NSString *) sPath {
    [MBProgressHUD showHUDAddedTo:self.view WithTitle:@"loading..." animated:YES];
    BOOL isDir;
    arrayFilePathVideos = [NSMutableArray array];
    [[NSFileManager defaultManager] fileExistsAtPath:sPath isDirectory:&isDir];
    if(isDir)
    {
        NSArray *contentOfDirectory=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:sPath error:NULL];
        int contentcount = [contentOfDirectory count];
        int i;
        for(i=0;i<contentcount;i++)
        {
            NSString *fileName = [contentOfDirectory objectAtIndex:i];
            NSString *path = [sPath stringByAppendingFormat:@"%@%@",@"/",fileName];
            
            if([[NSFileManager defaultManager] isDeletableFileAtPath:path])
            {
                NSString *typeFile = [[path componentsSeparatedByString:@"."]lastObject];
                if ([typeFile isEqualToString:@"mp4"]) {
                    NSString *fileNameOfPath = [[path componentsSeparatedByString:@"/"]lastObject];
                    NSString *fileNameIdTrip = [[fileNameOfPath componentsSeparatedByString:@"_"]objectAtIndex:1];
                    int tripValueID = [[NSUserDefaults standardUserDefaults]integerForKey:@"userTripId"];
                    NSString *tripId = [NSString stringWithFormat:@"%i",tripValueID];
                    
                    if ([fileNameIdTrip isEqualToString:tripId]) {
                        SlideVideo *slide = [[SlideVideo alloc]init];
                        NSURL *url = [NSURL fileURLWithPath:path];
                        MPMoviePlayerController *player = [[MPMoviePlayerController alloc] initWithContentURL:url];
                        UIImage *image = [player thumbnailImageAtTime:1.0 timeOption:MPMovieTimeOptionNearestKeyFrame];
                        [slide initData:path choosed:0 thumnail:image];
                        [arrayFilePathVideos addObject:slide];
                        NSLog(@"fileNameOfPath :%@",fileNameOfPath);
                    }
                    //[self scanPath:path];
                }
            }
        }
    }
    else{
    }
    
    
}
- (void) loadVideoSlideShow{
    for (UIView *subView in scrollPreviews.subviews) {
        [subView removeFromSuperview];
    }
    float x = 0;
    float y = 5;
    for (int i = 0; i < arrayFilePathVideos.count; i++) {
        SlideVideo *slide = [arrayFilePathVideos objectAtIndex:i];
        slide.choosed=0;
        if (i % 3 == 0 ) {
            x = 5;
        }else
            x+= 105;
        y = 105*(i/3)+5;
        
        AsynImageButton *asynImgBtn = [[AsynImageButton alloc] initWithFrame:CGRectMake(x, y, 100, 100)];
        asynImgBtn.tag = TagImage+i;
        [asynImgBtn loadIMageFromImage:slide.thumnail];
        [asynImgBtn addTarget:self action:@selector(previewVideoSlideShow:) forControlEvents:UIControlEventTouchUpInside];
        [scrollPreviews addSubview:asynImgBtn];
        UIButton *btnSync = [[UIButton alloc] initWithFrame:CGRectMake(x+80, y+2, 20, 23)];
        [btnSync setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        btnSync.tag = TagImageClickSync+i;
        [scrollChooseVideo addSubview:btnSync];
        btnSync.hidden=YES;
    }
    [scrollPreviews setContentSize:CGSizeMake(300, y+105)];
    scrollPreviews.layer.borderColor = [UIColor darkGrayColor].CGColor;
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
}
- (void) loadVideoSlideShowChooseToSend{
    for (UIView *subView in scrollChooseVideo.subviews) {
        [subView removeFromSuperview];
    }
    float x = 0;
    float y = 5;
    scrollChooseVideo.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgScrollImages.png"]];
    for (int i = 0; i < arrayFilePathVideos.count; i++) {
        SlideVideo *slide = [arrayFilePathVideos objectAtIndex:i];
        if (i % 3 == 0 ) {
            x = 5;
        }else
            x+= 105;
        y = 105*(i/3)+5;
        
        AsynImageButton *asynImgBtn = [[AsynImageButton alloc] initWithFrame:CGRectMake(x, y, 100, 100)];
        asynImgBtn.tag = TagImage+i;
        [asynImgBtn loadIMageFromImage:slide.thumnail];
        [asynImgBtn addTarget:self action:@selector(chooseVideoTosend:) forControlEvents:UIControlEventTouchUpInside];
        [scrollChooseVideo addSubview:asynImgBtn];
        
        UIButton *btnSync = [[UIButton alloc] initWithFrame:CGRectMake(x+80, y+2, 20, 23)];
        [btnSync setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        btnSync.tag = TagImageClickSync+i;
        [scrollChooseVideo addSubview:btnSync];
        if (slide.choosed == 0) {
            btnSync.hidden=YES;
        }
        else
            btnSync.hidden=NO;
    }
    [scrollChooseVideo setContentSize:CGSizeMake(300, y+105)];
    scrollChooseVideo.layer.borderColor = [UIColor darkGrayColor].CGColor;
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

- (void) chooseVideoTosend:(id)sender{
    
    [self.view endEditing:YES];
    UIButton *btn = (UIButton *)sender;
    SlideVideo *slide = [arrayFilePathVideos objectAtIndex:btn.tag-TagImage];
    
    if (slide.choosed == 0) {
        for (SlideVideo *slideVD in arrayFilePathVideos) {
            slideVD.choosed =0;
        }
        slide.choosed=1;
        arrayFilePathSaved = [NSMutableArray array];
        [arrayFilePathSaved addObject:slide];
    }else{
        for (SlideVideo *slideVD  in arrayFilePathVideos) {
            slideVD.choosed=0;
        }
        arrayFilePathSaved = [NSMutableArray array];
    }
    [self loadVideoSlideShowChooseToSend];
}

-(void) previewVideoSlideShow:(id)sender{
    UIButton *btn = (UIButton *)sender;
    SlideVideo *slide = [arrayFilePathVideos objectAtIndex:btn.tag-TagImage];
    NSURL *urlVideo = [NSURL fileURLWithPath:slide.urlVideo];
    [self playVedio:urlVideo];
}
#pragma mark play video
-(void)playVedio:(NSURL*)moviePath{
    mp = [[MPMoviePlayerViewController alloc] initWithContentURL:moviePath];
    
    [[mp moviePlayer] prepareToPlay];
    [[mp moviePlayer] setUseApplicationAudioSession:NO];
    [[mp moviePlayer] setShouldAutoplay:YES];
    [[mp moviePlayer] setControlStyle:2];
    [[mp moviePlayer] setRepeatMode:MPMovieRepeatModeOne];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayBackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    [self presentMoviePlayerViewControllerAnimated:mp];
}

-(void)videoPlayBackDidFinish:(NSNotification*)notification  {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    [mp.moviePlayer stop];
    mp = nil;
    [self dismissMoviePlayerViewControllerAnimated];
}


#pragma mark send email
- (IBAction)btnSendSlideShowClick:(id)sender {
    NSString *stringPath = [FileHelper videoDirectory];
    [self scanPath:stringPath];
    if (arrayFilePathVideos.count==0) {
        [delegate showAlert:@"Please create slide show"];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }else{
        [self loadVideoSlideShowChooseToSend];
        mainScroll.hidden = YES;
        scrollPreviews.hidden=YES;
        scrollChooseVideo.hidden=NO;
        btnDone.hidden=YES;
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            scrollChooseVideo.frame = CGRectMake(0, 40, scrollChooseVideo.frame.size.width, scrollChooseVideo.frame.size.height);
            btnDone.hidden=NO;
        } completion:nil];
        
    }
}

- (void)showEmail:(NSString*)file {
    SlideVideo *slide = [arrayFilePathSaved objectAtIndex:0];
    NSString *emailTitle = @"Travel buddy share slide show";
    NSString *messageBody = @"Hey, check this out!";
    NSArray *toRecipents = [NSArray arrayWithObject:@" "];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    [mc setSubject:emailTitle];
    [mc setMessageBody:messageBody isHTML:NO];
    [mc setToRecipients:toRecipents];
    
    // Determine the file name and extension
    //NSArray *filepart = [file componentsSeparatedByString:@"."];
    NSString *filename = [[file componentsSeparatedByString:@"."]objectAtIndex:0];
    NSString *extension = @"mp4";
    
    // Get the resource path and read the file using NSData
    NSData *fileData = [NSData dataWithContentsOfFile:slide.urlVideo];
    
    // Determine the MIME type
    NSString *mimeType;
    if ([extension isEqualToString:@"jpg"]) {
        mimeType = @"image/jpeg";
    } else if ([extension isEqualToString:@"png"]) {
        mimeType = @"image/png";
    } else if ([extension isEqualToString:@"doc"]) {
        mimeType = @"application/msword";
    } else if ([extension isEqualToString:@"ppt"]) {
        mimeType = @"application/vnd.ms-powerpoint";
    } else if ([extension isEqualToString:@"html"]) {
        mimeType = @"text/html";
    } else if ([extension isEqualToString:@"pdf"]) {
        mimeType = @"application/pdf";
    }else if ([extension isEqualToString:@"mp4"]) {
        mimeType = @"application/movie";
    }
    
    // Add attachment
    [mc addAttachmentData:fileData mimeType:mimeType fileName:file];
    
    // Present mail view controller on screen
    [self presentViewController:mc animated:YES completion:NULL];
    
}

#pragma mark mail delegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    // Notifies users about errors associated with the interface
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Result: canceled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Result: saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Result: sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Result: failed");
            break;
        default:
            NSLog(@"Result: not sent");
            break;
    }
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark action done choose video to send
- (IBAction)actionDoneChooseVideo:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        scrollChooseVideo.frame = CGRectMake(0, self.view.frame.size.height, scrollChooseVideo.frame.size.width, scrollChooseVideo.frame.size.height);
        btnDone.hidden=YES;
        [viewSharing bringSubviewToFront:self.view];
        if (arrayFilePathSaved.count>0) {
            viewSharing.hidden=NO;
            mainScroll.hidden=NO;
        }else{
            viewSharing.hidden=YES;
        }
    } completion:nil];
}
//method of sub view create slide show

- (IBAction)btnCancelClick:(id)sender {
    viewSharing.hidden = YES;
}

#pragma mark send to twitter
- (IBAction)sendToTwitter:(id)sender {
    subViewCreateSlide.hidden = YES;
}

#pragma mark send to mail
- (IBAction)btnSendMailCreateSlideClick:(id)sender {
    SlideVideo *slide = [arrayFilePathSaved objectAtIndex:0];
    NSString *fileName = [[slide.urlVideo componentsSeparatedByString:@"/"]lastObject];
    [self showEmail:fileName];
    
    //subViewCreateSlide.hidden = YES;
}

#pragma mark send to facebook
- (IBAction)btnSendFacebookCreateSlideClick:(id)sender {
    [self uploadVideoToServer];
}

- (void)uploadVideoToServer
{
    [MBProgressHUD showHUDAddedTo:self.view WithTitle:@"Uploading" animated:YES];
    SlideVideo *slide = [arrayFilePathSaved objectAtIndex:0];
    
    int userID = [[NSUserDefaults standardUserDefaults]integerForKey:@"userId"];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:30];
    [request setHTTPMethod:@"POST"];
    //flag(=1), client_ver, ownerid, photourl, isreceipt(=0,=1), caption, clientid
    NSMutableDictionary* _params = [[NSMutableDictionary alloc] init];
    [_params setObject:[NSNumber numberWithInt:userID] forKey:@"user_id"];
    
    
    //- Commit ảnh và update data, có input: flag(=1), client_ver, ownerid, photourl, isreceipt(=0,=1), caption, clientid
    NSString *BoundaryConstant = @"V2ymHFg03ehbqgZCaKO6jy";
    
    // string constant for the post parameter 'file'
    NSString *FileParamConstant = @"slideshow";
    //Setup request URL
    NSURL *requestURL = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"%@/upload_slideshow.php",SERVER_LINK]];
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", BoundaryConstant];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    for (NSString *param in _params) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", param] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", [_params objectForKey:param]] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    // add image data
    NSData *videoData = [NSData dataWithContentsOfFile:slide.urlVideo];
    if (videoData) {
        printf("appending image data\n");
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\'%@\'; filename=\".mp4\"\r\n", FileParamConstant] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:videoData];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", BoundaryConstant] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%d", [body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    // set URL
    [request setURL:requestURL];
    
    NSURLResponse *response = nil;
    NSError *error=nil;
    NSData *data=[[NSData alloc] initWithData:[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error]];
    
    NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    NSLog(@"Upload Video : %@",dict);
    NSString *message = [dict objectForKey:@"message"];
    NSLog(@"=== message : %@",message);
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    if ([message isEqualToString:@"uploaded successfully"]) {
        NSString *pathVideo = [dict objectForKey:@"path"];
        urlShareSlideShow = [NSString stringWithFormat:@"%@%@",SERVER_LINK,pathVideo];
        [self shareToFaceBook];
    }else if([message isEqualToString:@"user_id is required"]){
        [delegate showAlert:@"Upload failed"];
    }
    
    //    if ([[[dict objectForKey:@"message"]stringValue] isEqualToString:@"uploaded successfully"]) {
    //        NSString *pathVideo = [[dict objectForKey:@"path"]stringValue];
    //        urlShareSlideShow = [NSString stringWithFormat:@"%@%@",SERVER_LINK,pathVideo];
    //        [self shareToFaceBook];
    //    }else{
    //
    //    }
}
- (void)shareToFaceBook{
    SlideVideo *slideVD = [arrayFilePathSaved objectAtIndex:0];
    SLComposeViewController *controller = [SLComposeViewController
                                           composeViewControllerForServiceType:SLServiceTypeFacebook];
    SLComposeViewControllerCompletionHandler myBlock =
    ^(SLComposeViewControllerResult result){
        if (result == SLComposeViewControllerResultCancelled)
        {
            [delegate showAlert:@"Post failed"];
        }
        else
        {
            [delegate showAlert:@"Post successed"];
        }
        mainScroll.hidden=NO;
        viewSharing.hidden=YES;
        [controller dismissViewControllerAnimated:YES completion:nil];
    };
    controller.completionHandler =myBlock;
    
    //Adding the Text to the facebook post value from iOS
    [controller setInitialText:@"Travel Buddy Share Slide Show"];
    //Adding the URL to the facebook post value from iOS
    [controller addImage:slideVD.thumnail];
    [controller addURL:[NSURL URLWithString:urlShareSlideShow]];
    //Adding the Text to the facebook post value from iOS
    [self presentViewController:controller animated:YES completion:nil];
    
}
@end
