//
//  AddPhotoVC.m
//  Fun Spot App
//
//  Created by Luong Anh on 8/15/14.
//
//

#import "AddPhotoVC.h"
#import "PhotoObj.h"
@interface AddPhotoVC ()

@end

@implementation AddPhotoVC
@synthesize isAddPhoto,isTakePhoto;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    float main_top = 0;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        main_top = 0;
    }
    CGRect mainRect = [[UIScreen mainScreen] bounds];
    self.itemsView = [[UIView alloc] initWithFrame:CGRectMake(-self.view.frame.size.width, main_top, self.view.frame.size.width-200, mainRect.size.height-main_top)];
    self.itemsView.hidden = YES;
    [self.view addSubview:self.itemsView];
    
    asynImgPhoto.layer.borderColor = [UIColor whiteColor].CGColor;
    asynImgPhoto.layer.borderWidth = 4.0;
    asynImgPhoto.layer.cornerRadius = 5.0;
    
    bgViewLabelDes.layer.cornerRadius = 5.0;
    isAddedPhoto = FALSE;
//    UIColor *color = [UIColor colorWithRed:248/255.0 green:216/255.0 blue:239/255.0 alpha:1.0];
    btnCancel.layer.cornerRadius = 4.0;
    if (isTakePhoto) {
        [self takePhotoClick:nil];
        lblTitleViewPhoto.text = @"Take photo";
    }
    if (isAddPhoto) {
        [self chooseFromLibClick:nil];
        lblTitleViewPhoto.text = @"Add photo";
    }
}
- (void)viewWillAppear:(BOOL)animated{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma UIImagePickerController
// get picture from library or take new picture
- (IBAction)btnPhotoClick:(id)sender {
    [self.view endEditing:YES];
    if (isTakePhoto) {
        [self takePhotoClick:nil];
        return;
    }
    if (isAddPhoto) {
        [self chooseFromLibClick:nil];
        return;
    }
    viewPhoto.hidden = NO;
}

- (IBAction)btnCancelImageClick:(id)sender {
    viewPhoto.hidden = YES;
}

- (IBAction)btnSaveClick:(id)sender {
    if (!isAddedPhoto) {
        [delegate showAlert:@"Please add a photo"];
        return;
    }
    NSString* strDes = [tfDescribePhoto.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([tfDescribePhoto.text isEqualToString:@""]) {
        [delegate showAlert:@"Please describe your photo"];
        return;
    }
    if (strDes.length == 0) {
        [delegate showAlert:@"Please input data"];
        return;
    }
    if (![tfDescribePhoto.text isEqualToString:@""] && tfDescribePhoto.text.length >40) {
        [delegate showAlert:@"Describle must have less than 40 character"];
        return;
    }
    //set image name
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSDate *date = [NSDate date];
    NSString *strDate = [dateFormatter stringFromDate:date];
    NSString *timeStamp =[NSString stringWithFormat:@"%@_%@.jpg",[userDef objectForKey:@"userId"],[[strDate stringByReplacingOccurrencesOfString:@" " withString:@""] stringByReplacingOccurrencesOfString:@":" withString:@""]];
    
    //write to file into local app
    NSData *pngData = UIImagePNGRepresentation(currentImage);
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0]; //Get the docs directory
    NSString *filePath = [documentsPath stringByAppendingPathComponent:timeStamp]; //Add the file name
    [pngData writeToFile:filePath atomically:YES];
    
    //save photo into local database
    IMSSqliteManager *sqlManager = [[IMSSqliteManager alloc] init];
    PhotoObj *photoObj = [[PhotoObj alloc] init];
    photoObj.caption   = tfDescribePhoto.text;
    photoObj.urlPhoto  = timeStamp;
    photoObj.isReceipt = 0;
    photoObj.tripId    = [[userDef objectForKey:@"userTripId"] intValue];
    photoObj.ownerUserId = [[userDef objectForKey:@"userId"] intValue];
    photoObj.serverId  = 0;
    photoObj.flag      = 1;
    @synchronized(self){
        [sqlManager addPhotoInfor:photoObj];
    }
    tfDescribePhoto.text = @"";
    [asynImgPhoto loadIMageFromImage:nil];
    btnAddPhotoSmall.hidden = NO;
    isAddedPhoto = FALSE;
    btnDelete.hidden = YES;
    [delegate showAlert:@"The photo was saved"];
}

- (IBAction)btnAddPhotoSmallClicck:(id)sender {
    [self btnPhotoClick:nil];
}

- (IBAction)btnYesClick:(id)sender {
    viewConfirmDeletePhoto.hidden = YES;
    btnDelete.hidden = YES;
    isAddedPhoto = FALSE;
    btnAddPhotoSmall.hidden = NO;
    [asynImgPhoto loadIMageFromImage:nil];
}

- (IBAction)btnNoClick:(id)sender {
    viewConfirmDeletePhoto.hidden = YES;
}
- (IBAction)takePhotoClick:(id)sender {
    NSString *model = [[UIDevice currentDevice] model];
    
    if ([model isEqualToString:@"iPhone Simulator"]) {
        UIAlertView *funSpoAlertView = [[UIAlertView alloc] initWithTitle:@"" message:@"Take Photo cannot be completed on simulator." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [funSpoAlertView show];
    }
    else
    {
        viewPhoto.hidden = YES;
        UIImagePickerController *pickerImage = [[UIImagePickerController alloc] init];
        pickerImage.delegate = self;
        pickerImage.allowsEditing = YES;
        pickerImage.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:pickerImage animated:YES completion:nil];
    }
}

- (IBAction)chooseFromLibClick:(id)sender {
    viewPhoto.hidden = YES;
    UIImagePickerController *pickerImage = [[UIImagePickerController alloc] init];
    pickerImage.delegate = self;
    pickerImage.allowsEditing = YES;
    pickerImage.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    [self presentViewController:pickerImage animated:YES completion:nil];
}

-(void)imagePickerController:(UIImagePickerController *)pickerImage
      didFinishPickingImage : (UIImage *)image
                 editingInfo:(NSDictionary *)editingInfo
{
    isAddedPhoto = TRUE;
    btnDelete.hidden = NO;
    btnAddPhotoSmall.hidden = YES;
    currentImage = image;
//    [asynImgPhoto setImage:image forState:UIControlStateNormal];
    [asynImgPhoto loadIMageFromImage:image];
    [pickerImage dismissModalViewControllerAnimated:YES];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *) pickerImage
{
    [pickerImage dismissViewControllerAnimated:YES completion:nil];
}
//action when click delete photo
- (IBAction)btnDeletePhotoCLick:(id)sender {
    viewConfirmDeletePhoto.hidden = NO;
}
//when click button home
- (IBAction)btnHomeClick:(id)sender {
    if (self.itemsView.hidden) {
        self.itemsView.hidden = NO;
        [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:YES delegate:self rect:self.itemsView.frame selected:@""];
        
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = 0;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];
    } else {
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = -rect.size.width;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             self.itemsView.hidden = YES;
                             [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:NO delegate:self rect:self.itemsView.frame selected:@""];
                         }];
    }
}

#pragma text field

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y - 155, self.view.frame.size.width, self.view.frame.size.height);
}

- (void) textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y + 155, self.view.frame.size.width, self.view.frame.size.height);
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    CGRect rect = self.itemsView.frame;
    if (rect.origin.x == 0) {
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = -rect.size.width;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             self.itemsView.hidden = YES;
                             [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:NO delegate:self rect:self.itemsView.frame selected:@""];
                         }];
    }else
        [self.view endEditing:YES];
}
@end
