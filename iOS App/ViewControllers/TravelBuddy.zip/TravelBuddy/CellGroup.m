//
//  CellGroup.m
//  Fun Spot App
//
//  Created by LE MINH TRI on 9/25/14.
//
//

#import "CellGroup.h"

@implementation CellGroup

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
