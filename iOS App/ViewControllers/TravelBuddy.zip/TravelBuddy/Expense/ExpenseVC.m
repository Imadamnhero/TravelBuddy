//
//  ExpenseVC.m
//  Fun Spot App
//
//  Created by Luong Anh on 8/15/14.
//
//

#import "ExpenseVC.h"
#import "AddExpenseVC.h"
#import "PCPieChart.h"
#import "TripDetailVC.h"

@interface ExpenseVC ()

@end

@implementation ExpenseVC
@synthesize numberRow;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    numberRow = 0;
    // Do any additional setup after loading the view from its nib.
    delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    float main_top = 0;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        main_top = 0;
    }
    CGRect mainRect = [[UIScreen mainScreen] bounds];
    self.itemsView = [[UIView alloc] initWithFrame:CGRectMake(-self.view.frame.size.width, main_top, self.view.frame.size.width-200, mainRect.size.height-main_top)];
    self.itemsView.hidden = YES;
    [self.view addSubview:self.itemsView];
    
    mainArray = [[NSMutableArray alloc] init];
    arrayEntertainment = [[NSMutableArray alloc] init];
    arrayFoodAndDrink = [[NSMutableArray alloc] init];
    arrayTaxi = [[NSMutableArray alloc] init];
    
//    [self drawRect:bgImageLinePercentBudget.frame];
    bgImgBudgetView.layer.cornerRadius = bgImgCircleView.layer.cornerRadius = 4.0;
    
    NSMutableDictionary *dictF = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom1.png",@"image",@"Cake",@"title",@"August 22, 2014",@"date",@"10.11",@"price", nil];
    [arrayFoodAndDrink addObject:dictF];
    NSMutableDictionary *dictF1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom2.png",@"image",@"Hot dog",@"title",@"August 23, 2014",@"date",@"9.91",@"price", nil];
    [arrayFoodAndDrink addObject:dictF1];
    NSMutableDictionary *dictF2 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom3.png",@"image",@"Coffee",@"title",@"August 24, 2014",@"date",@"8.81",@"price", nil];
    [arrayFoodAndDrink addObject:dictF2];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom1.png",@"image",@"Magazine",@"title",@"August 22, 2014",@"date",@"11.11",@"price", nil];
    [arrayEntertainment addObject:dict];
    NSMutableDictionary *dict1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom2.png",@"image",@"Dolor sit amet",@"title",@"August 23, 2014",@"date",@"12.91",@"price", nil];
    [arrayEntertainment addObject:dict1];
    NSMutableDictionary *dict2 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom3.png",@"image",@"Lorem ipsum",@"title",@"August 24, 2014",@"date",@"13.81",@"price", nil];
    [arrayEntertainment addObject:dict2];
    
    NSMutableDictionary *dictT = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom1.png",@"image",@"Yellow Cab",@"title",@"August 22, 2014",@"date",@"31.11",@"price", nil];
    [arrayTaxi addObject:dictT];
    NSMutableDictionary *dictT1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom2.png",@"image",@"Urban",@"title",@"August 23, 2014",@"date",@"32.91",@"price", nil];
    [arrayTaxi addObject:dictT1];
    NSMutableDictionary *dictT2 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"imagesTom3.png",@"image",@"NY taxi",@"title",@"August 24, 2014",@"date",@"29.81",@"price", nil];
    [arrayTaxi addObject:dictT2];
    
    CGRect rect = mainTable.frame;
    rect.size.height = mainArray.count*44+120;
    mainTable.frame = rect;
    [mainScroll setContentSize:CGSizeMake(320, mainTable.frame.origin.y + mainTable.frame.size.height + 100)];
    
    isFood = isEnte = isTaxi = FALSE;
    mainTable.allowsSelectionDuringEditing = YES;
    
    btnCheckFood = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 300, 40)];
    btnCheckFood.tag = 5000;
    [btnCheckFood addTarget:self action:@selector(checkBoxSelected:) forControlEvents:UIControlEventTouchUpInside];
    NSString* strNormalStatus   = @"icon_dropdown.png";
    NSString* strSelectedStatus = @"icon_dropdown_blue.png";
    [btnCheckFood setImage:[UIImage imageNamed:strNormalStatus] forState:UIControlStateNormal];
    [btnCheckFood setImage:[UIImage imageNamed:strSelectedStatus] forState:UIControlStateHighlighted];
    btnCheckFood.imageEdgeInsets = UIEdgeInsetsMake(15, 282, 15, 0);
    
    btnCheckEnt = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 300, 40)];
    btnCheckEnt.tag = 5001;
    [btnCheckEnt addTarget:self action:@selector(checkBoxSelected:) forControlEvents:UIControlEventTouchUpInside];
    strNormalStatus   = @"icon_dropdown.png";
    strSelectedStatus = @"icon_dropdown_purpil.png";
    [btnCheckEnt setImage:[UIImage imageNamed:strNormalStatus] forState:UIControlStateNormal];
    [btnCheckEnt setImage:[UIImage imageNamed:strSelectedStatus] forState:UIControlStateHighlighted];
    btnCheckEnt.imageEdgeInsets = UIEdgeInsetsMake(15, 282, 15, 0);
    
    btnCheckTaxi = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 300, 40)];
    btnCheckTaxi.tag = 5002;
    [btnCheckTaxi addTarget:self action:@selector(checkBoxSelected:) forControlEvents:UIControlEventTouchUpInside];
    strNormalStatus   = @"icon_dropdown.png";
    strSelectedStatus = @"icon_dropdown_yellow.png";
    [btnCheckTaxi setImage:[UIImage imageNamed:strNormalStatus] forState:UIControlStateNormal];
    [btnCheckTaxi setImage:[UIImage imageNamed:strSelectedStatus] forState:UIControlStateHighlighted];
    btnCheckTaxi.imageEdgeInsets = UIEdgeInsetsMake(15, 282, 15, 0);
    
    [budgetAmount setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:17.f]];
    [lblBudgetAmount setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:17.f]];
    [spentAmout setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:14.f]];
    [lblSpentAmount setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:14.f]];
    [remainingAmount setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:14.f]];
    [lblRemainingAmount setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:14.f]];
}
- (void) drawSpent{
    float sumFood = 0;
    for (int i = 0; i < arrayFoodAndDrink.count; i++) {
        ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
        expenseObj = [arrayFoodAndDrink objectAtIndex:i];
        sumFood += [expenseObj.money floatValue];
    }
    
    float sumEnt = 0;
    for (int i = 0; i < arrayEntertainment.count; i++) {
        ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
        expenseObj = [arrayEntertainment objectAtIndex:i];
        sumEnt += [expenseObj.money floatValue];
    }
    
    float sumTaxi = 0;
    for (int i = 0; i < arrayTaxi.count; i++) {
        ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
        expenseObj = [arrayTaxi objectAtIndex:i];
        sumTaxi += [expenseObj.money floatValue];
    }
    
    float sum = sumFood + sumEnt + sumTaxi;
    spentAmout.text = [NSString stringWithFormat:@"$ %0.2f",sum];
    float numberRemaining = [[budgetAmount.text substringFromIndex:2] floatValue] - sum;
    remainingAmount.text = [NSString stringWithFormat:@"$ %0.2f",numberRemaining];
    [self drawRect:bgImageLinePercentBudget.frame];
    
    [mainArray removeAllObjects];
    
    NSString *strPercentFood = @"0";
    if (sum != 0) {
        strPercentFood = [NSString stringWithFormat:@"%0.2f",sumFood/sum*100];
    }
    NSMutableDictionary *dictM = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%0.2f",sumFood],@"price",strPercentFood,@"percent", nil];
    [mainArray addObject:dictM];
    
    NSString *strPercentEnt = @"0";
    if (sum != 0) {
        strPercentEnt = [NSString stringWithFormat:@"%0.2f",sumEnt/sum*100];
    }
    NSMutableDictionary *dictM1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Entertainment:",@"title",[NSString stringWithFormat:@"%0.2f",sumEnt],@"price",strPercentEnt,@"percent", nil];
    [mainArray addObject:dictM1];
    
    NSString *strPercentMov = @"0";
    if (sum != 0) {
        strPercentMov = [NSString stringWithFormat:@"%0.2f",sumTaxi/sum*100];
    }
    NSMutableDictionary *dictM2 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Movement:",@"title",[NSString stringWithFormat:@"%0.2f",sumTaxi],@"price",strPercentMov,@"percent", nil];
    [mainArray addObject:dictM2];
    
    [mainTable reloadData];
    [self drawRectLineLeftTable];
    NSMutableArray *arrayCircel = [[NSMutableArray alloc] init];
    
    NSMutableDictionary *dictFoodCir = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%02.f",sumFood],@"value", nil];
    [arrayCircel addObject:dictFoodCir];
    
    NSMutableDictionary *dictEntCir = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%02.f",sumEnt],@"value", nil];
    [arrayCircel addObject:dictEntCir];
    
    NSMutableDictionary *dictMovCir = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%02.f",sumTaxi],@"value", nil];
    [arrayCircel addObject:dictMovCir];
    
    if (sum != 0) {
        [self drawCircle:arrayCircel];
    }else
        [self.view bringSubviewToFront:lblNoExpenseAdded];
}
- (void)viewWillAppear:(BOOL)animated{
    [arrayFoodAndDrink removeAllObjects];
    [arrayEntertainment removeAllObjects];
    [arrayTaxi removeAllObjects];
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    IMSSqliteManager *sqliteManager = [[IMSSqliteManager alloc] init];
    NSMutableArray *arrayExp = [[NSMutableArray alloc] init];
    TripObj *tripInfor = [[TripObj alloc] init];
    @synchronized(self)
    {
        //get trip infor to get budget
        tripInfor  = [[sqliteManager getTripInfor:[[userDefault objectForKey:@"userId"] intValue]] objectAtIndex:0];
        budgetAmount.text = [NSString stringWithFormat:@"$ %@",tripInfor.budget];
        
        //get all expenses
        arrayExp = [sqliteManager getExpenses];
    }
//    if (arrayExp.count > 0) {
        for (int i = 0 ; i < arrayExp.count ; i++) {
            ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
            expenseObj = [arrayExp objectAtIndex:i];
            if (expenseObj.cateId == 1) {
                [arrayFoodAndDrink addObject:expenseObj];
            }else if (expenseObj.cateId == 2){
                [arrayEntertainment addObject:expenseObj];
            }else
                [arrayTaxi addObject:expenseObj];
        }
        mainTable.allowsSelectionDuringEditing = YES;
        [self drawSpent];
//    }
    
//    float sumFood = 0;
//    for (int i = 0; i < arrayFoodAndDrink.count; i++) {
//        ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
//        expenseObj = [arrayFoodAndDrink objectAtIndex:i];
//        sumFood += [expenseObj.money floatValue];
//    }
//    
//    float sumEnt = 0;
//    for (int i = 0; i < arrayEntertainment.count; i++) {
//        ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
//        expenseObj = [arrayEntertainment objectAtIndex:i];
//        sumEnt += [expenseObj.money floatValue];
//    }
//    
//    float sumTaxi = 0;
//    for (int i = 0; i < arrayTaxi.count; i++) {
//        ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
//        expenseObj = [arrayTaxi objectAtIndex:i];
//        sumTaxi += [expenseObj.money floatValue];
//    }
//    
//    float sum = sumFood + sumEnt + sumTaxi;
//    spentAmout.text = [NSString stringWithFormat:@"$ %0.2f",sum];
//    float numberRemaining = [tripInfor.budget floatValue] - sum;
//    remainingAmount.text = [NSString stringWithFormat:@"$ %0.2f",numberRemaining];
//    [self drawRect:bgImageLinePercentBudget.frame];
//    
//    [mainArray removeAllObjects];
//    NSString *strPercentFood = @"0";
//    if (sum != 0) {
//        strPercentFood = [NSString stringWithFormat:@"%0.2f",sumFood/sum*100];
//    }
//    NSMutableDictionary *dictM = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%0.2f",sumFood],@"price",strPercentFood,@"percent", nil];
//    [mainArray addObject:dictM];
//    
//    NSString *strPercentEnt = @"0";
//    if (sum != 0) {
//        strPercentEnt = [NSString stringWithFormat:@"%0.2f",sumEnt/sum*100];
//    }
//    NSMutableDictionary *dictM1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Entertainment:",@"title",[NSString stringWithFormat:@"%0.2f",sumEnt],@"price",strPercentEnt,@"percent", nil];
//    [mainArray addObject:dictM1];
//    
//    NSString *strPercentMov = @"0";
//    if (sum != 0) {
//        strPercentMov = [NSString stringWithFormat:@"%0.2f",sumTaxi/sum*100];
//    }
//    NSMutableDictionary *dictM2 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Movement:",@"title",[NSString stringWithFormat:@"%0.2f",sumTaxi],@"price",strPercentMov,@"percent", nil];
//    [mainArray addObject:dictM2];
//    
//    [mainTable reloadData];
//    
//    NSMutableArray *arrayCircel = [[NSMutableArray alloc] init];
//    
//    NSMutableDictionary *dictFoodCir = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%02.f",sumFood],@"value", nil];
//    [arrayCircel addObject:dictFoodCir];
//    
//    NSMutableDictionary *dictEntCir = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%02.f",sumEnt],@"value", nil];
//    [arrayCircel addObject:dictEntCir];
//    
//    NSMutableDictionary *dictMovCir = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"Food & Drink:",@"title",[NSString stringWithFormat:@"%02.f",sumTaxi],@"value", nil];
//    [arrayCircel addObject:dictMovCir];
//    
//    if (sum != 0) {
//        [self drawCircle:arrayCircel];
//    }else
//        [self.view bringSubviewToFront:lblNoExpenseAdded];
    
}

- (void) drawCircle:(NSMutableArray*)arrayInfor{
    
    int height = viewCirclePercent.frame.size.width/3*2.;
    int width = viewCirclePercent.frame.size.width;
    PCPieChart *pieChart = [[PCPieChart alloc] initWithFrame:CGRectMake((viewCirclePercent.frame.size.width-width)/2,(viewCirclePercent.frame.size.height-height)/2,width,height)];
    
    [pieChart setShowArrow:NO];
    [pieChart setSameColorLabel:YES];
    [pieChart setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleBottomMargin];
    [pieChart setDiameter:width/2];
    [viewCirclePercent addSubview:pieChart];
    
//    NSString *sampleFile = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"sample_piechart_data.plist"];
//    NSDictionary *sampleInfo = [NSDictionary dictionaryWithContentsOfFile:sampleFile];
    NSMutableArray *components = [NSMutableArray array];
    for (int i=0; i<[arrayInfor count]; i++)
    {
        NSDictionary *item = [arrayInfor objectAtIndex:i];
        PCPieComponent *component = [PCPieComponent pieComponentWithTitle:[item objectForKey:@"title"] value:[[item objectForKey:@"value"] floatValue]];
        [components addObject:component];
        
        if (i==0)
        {
            [component setColour:PCColorBlue];
        }
        else if (i==1)
        {
            [component setColour:PCColorViolet];
        }
        else if (i==2)
        {
            [component setColour:PCColorYellow];
        }
    }
    [pieChart setComponents:components];
}

- (void)drawRect:(CGRect)rect {
    bgImageLinePercentBudget.layer.cornerRadius = 3.0;
    float numberBudget = [[budgetAmount.text substringFromIndex:2] floatValue];
    if (numberBudget == 0) {
        numberBudget = 2200;
    }
    float numberSpent = [[spentAmout.text substringFromIndex:2] floatValue];
    float percent = numberSpent/numberBudget;
    if (percent>1) {
        percent = 1;
    }
    rect.size.width = 300*percent;
    bgImageLinePercentBudget.frame = rect;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnHomeClick:(id)sender {
    if (self.itemsView.hidden) {
        self.itemsView.hidden = NO;
        [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:YES delegate:self rect:self.itemsView.frame selected:@""];
        
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = 0;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];
    } else {
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = -rect.size.width;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             self.itemsView.hidden = YES;
                             [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:NO delegate:self rect:self.itemsView.frame selected:@""];
                         }];
    }
}

- (IBAction)AddNewExpensiveClick:(id)sender {
    AddExpenseVC *addExpensiveController = [[AddExpenseVC alloc] initWithNibName:@"AddExpenseVC" bundle:nil parent:self];
    [self.navigationController pushViewController:addExpensiveController animated:YES];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            if (isFood) {
                return arrayFoodAndDrink.count;
            }else
                return 0;
            break;
        case 1:
            if (isEnte) {
                return arrayEntertainment.count;
            }else
                return 0;
            break;
        case 2:
            if (isTaxi) {
                return arrayTaxi.count;
            }else
                return 0;
            break;
        default:
            break;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    //    static NSString *CellIdentifier = @"Cell";
    //    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    //
    //    if (cell == nil) {
    //        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    //    }
    
    //create user avatar
//    NSString* strImageName = userObj.user_pic;
//    NSData *imageData = [sqlManager image:strImageName];
//    UIImage *imageUser = [UIImage imageWithData:imageData scale:1];
//    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 10, 50, 50)];
//    imgView.image = imageUser; //[Common thumbWithSideOfLength:50:imageUser];
//    imgView.layer.cornerRadius = 10.0f;
//    imgView.clipsToBounds=YES;
//    [cell.contentView addSubview:imgView];
    
    ExpenseObj *expenseObj = [[ExpenseObj alloc] init];
    if (indexPath.section == 0) {
        expenseObj = [arrayFoodAndDrink objectAtIndex:indexPath.row];
    }else if (indexPath.section == 1){
        expenseObj = [arrayEntertainment objectAtIndex:indexPath.row];
    }else
        expenseObj = [arrayTaxi objectAtIndex:indexPath.row];
    
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 120, 21)];
    lblTitle.text = [NSString stringWithFormat:@"%@",expenseObj.item];
    [lblTitle setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:13.f]];
    lblTitle.textColor = [UIColor whiteColor];
    [cell.contentView addSubview:lblTitle];
    
    
    UILabel *lblPrice = [[UILabel alloc] initWithFrame:CGRectMake(125, 5, 70, 21)];
    lblPrice.text = [NSString stringWithFormat:@"$ %@",expenseObj.money];
    lblPrice.textAlignment = NSTextAlignmentRight;
    [lblPrice setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:13.f]];
    lblPrice.textColor = [UIColor whiteColor];
    [cell.contentView addSubview:lblPrice];
    
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    dateFormatter.dateFormat = @"yyyy-MM-dd";
    NSDate *date = [dateFormatter dateFromString:expenseObj.dateTime];
    [dateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"]];
    dateFormatter.dateFormat = @"MMM dd, yyyy";
    NSString *strDate = [dateFormatter stringFromDate:date];
    
    UILabel *lblDate = [[UILabel alloc] initWithFrame:CGRectMake(200, 5,100, 21)];
    lblDate.text = [NSString stringWithFormat:@"%@",strDate];
    lblDate.textAlignment = NSTextAlignmentRight;
    [lblDate setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:13.f]];
    lblDate.textColor = [UIColor whiteColor];
    [cell.contentView addSubview:lblDate];
    
    cell.textLabel.numberOfLines = 0;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (indexPath.row %2 == 0) {
        cell.backgroundColor = [UIColor colorWithRed:57/255.0 green:56/255.0 blue:57/255.0 alpha:1.0];
    }else
        cell.backgroundColor = [UIColor colorWithRed:68/255.0 green:68/255.0 blue:68/255.0 alpha:1.0];
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 40)];
    UIImage *imgBgCell = [UIImage imageNamed:@"bgImgCell.png"];
    UIImageView *imgCelBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    imgCelBgView.image = imgBgCell;
    [view addSubview:imgCelBgView];
    
    view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    /* Create custom view to display section header... */
    
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(10, 9, 110, 22)];
    lblTitle.textColor = [UIColor darkGrayColor];
    lblTitle.text = [[mainArray objectAtIndex:section] objectForKey:@"title"];
    [lblTitle setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:15.f]];
    [view addSubview:lblTitle];
    
    /*
    UIButton *btnCheck = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 250, 22)];
    btnCheck.tag = section + 5000;
    [btnCheck addTarget:self action:@selector(checkBoxSelected:) forControlEvents:UIControlEventTouchUpInside];
    NSString* strNormalStatus   = @"icon_dropdown.png";
    NSString* strSelectedStatus = @"icon_dropdown.png";
    if (section == 0) {
        strSelectedStatus = @"icon_dropdown_blue.png";
    }else if (section == 1) {
        strSelectedStatus = @"icon_dropdown_purpil.png";
    }else
        strSelectedStatus = @"icon_dropdown_yellow.png";
    [btnCheck setImage:[UIImage imageNamed:strNormalStatus] forState:UIControlStateNormal];
    [btnCheck setImage:[UIImage imageNamed:strSelectedStatus] forState:UIControlStateHighlighted];
    [view addSubview:btnCheck];
    */
    if (section == 0) {
        [view addSubview:btnCheckFood];
    }else if (section == 1) {
        [view addSubview:btnCheckEnt];
    }else
        [view addSubview:btnCheckTaxi];
    
    UILabel *lblTotal = [[UILabel alloc] initWithFrame:CGRectMake(125, 9, 155, 22)];
    lblTotal.textAlignment = NSTextAlignmentRight;
    lblTotal.textColor = [UIColor darkGrayColor];
    lblTotal.text = [NSString stringWithFormat:@"$ %@ (%@%%)",[[mainArray objectAtIndex:section] objectForKey:@"price"],[[mainArray objectAtIndex:section] objectForKey:@"percent"]];
    [lblTotal setFont:[UIFont fontWithName:@"MyriadPro-Bold" size:15.f]];
    [view addSubview:lblTotal];
    
    return view;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
// action event of check box
- (void)checkBoxSelected:(id)sender{
    UIButton *btn = (UIButton*)sender;
    int tag = btn.tag - 5000;
    
    if (tag == 0){
        isFood = !isFood;
        if (isFood){
            numberRow += arrayFoodAndDrink.count;
            [btn setImage:[UIImage imageNamed:@"icon_dropdown_blue.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"icon_dropdown.png"] forState:UIControlStateNormal];
            numberRow -= arrayFoodAndDrink.count;
        }
    }
    else if (tag == 1){
        isEnte = !isEnte;
        if (isEnte){
            numberRow += arrayEntertainment.count;
            [btn setImage:[UIImage imageNamed:@"icon_dropdown_purpil.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"icon_dropdown.png"] forState:UIControlStateNormal];
            numberRow -= arrayEntertainment.count;
        }
    }
    else {
        isTaxi = !isTaxi;
        if (isTaxi){
            numberRow += arrayTaxi.count;
            [btn setImage:[UIImage imageNamed:@"icon_dropdown_yellow.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"icon_dropdown.png"] forState:UIControlStateNormal];
            numberRow -= arrayTaxi.count;
        }
    }
    [self drawRectLineLeftTable];
}
#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        //        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        ExpenseObj *obj = [[ExpenseObj alloc] init];
        
        if (indexPath.section == 0) {
            obj = [arrayFoodAndDrink objectAtIndex:indexPath.row];
            [arrayFoodAndDrink removeObjectAtIndex:indexPath.row];
        }else if(indexPath.section == 1) {
            obj = [arrayEntertainment objectAtIndex:indexPath.row];
            [arrayEntertainment removeObjectAtIndex:indexPath.row];
        }else{
            obj = [arrayTaxi objectAtIndex:indexPath.row];
            [arrayTaxi removeObjectAtIndex:indexPath.row];
        }
        numberRow -= 1;
        [self drawRectLineLeftTable];
        [self drawSpent];
        //update local database
        IMSSqliteManager* sqlManager = [[IMSSqliteManager alloc] init];
        obj.flag = 3;
        @synchronized(self)
        {
            [sqlManager updateExpense:obj];
        }
        
        //check connection internet and sync expense
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        Reachability *reach = [Reachability reachabilityForInternetConnection];
        NetworkStatus netStatus = [reach currentReachabilityStatus];
        if (netStatus == NotReachable) {
            //        [Common showNetworkFailureAlert];
        } else {
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                // sync note
                [userDef setObject:@"0" forKey:@"syncExpense"];
                [userDef synchronize];
                [TripDetailVC SyncExpenseData];
            });
        }
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}
- (void) drawRectLineLeftTable{
    //set line Left of each section
    //line left of Food & Drink
    float heightFood = 40;
    float yFood = lineLeftFood.frame.origin.y;
    if (isFood) {
        heightFood += arrayFoodAndDrink.count*30;
    }
    yFood +=heightFood;
    CGRect rectFood = lineLeftFood.frame;
    rectFood.size.height = heightFood;
    lineLeftFood.frame = rectFood;
    
    //line left of Entertainment
    float heightEnt = 40;
    if (isEnte) {
        heightEnt = 40 + arrayEntertainment.count*30;
    }
    CGRect rectEnt = lineLeftEntertainment.frame;
    rectEnt.size.height = heightEnt;
    rectEnt.origin.y = yFood;
    lineLeftEntertainment.frame = rectEnt;
    yFood += heightEnt;
    //line left of Taxi
    float heightTaxi = 40;
    if (isTaxi) {
        heightTaxi = 40 + arrayTaxi.count*30;
    }
    CGRect rectTaxi = lineLeftTaxi.frame;
    rectTaxi.size.height = heightTaxi;
    rectTaxi.origin.y = yFood;
    lineLeftTaxi.frame = rectTaxi;
    
    //reset frame table
    CGRect rect = mainTable.frame;
    rect.size.height = numberRow*30+120;
    mainTable.frame = rect;
    
    CGRect mainRect = [[UIScreen mainScreen] bounds];
    if (mainRect.size.height > 480) {
        [mainScroll setContentSize:CGSizeMake(320, mainTable.frame.origin.y + mainTable.frame.size.height + 10)];
    }else
        [mainScroll setContentSize:CGSizeMake(320, mainTable.frame.origin.y + mainTable.frame.size.height + 100)];

    [mainTable reloadData];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    CGRect rect = self.itemsView.frame;
    if (rect.origin.x == 0) {
        [UIView animateWithDuration:0.2f
                              delay:0.1f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             CGRect rect = self.itemsView.frame;
                             rect.origin.x = -rect.size.width;
                             self.itemsView.frame = rect;
                         }
                         completion:^(BOOL finished){
                             self.itemsView.hidden = YES;
                             [delegate.leftTabBarViewCtrl showLeftTabBar:self.itemsView show:NO delegate:self rect:self.itemsView.frame selected:@""];
                         }];
    }else
        [self.view endEditing:YES];
}
@end
